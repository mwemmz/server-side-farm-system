<?php
require_once __DIR__ . '/CropModel.php';
require_once __DIR__ . '/../Pest/PestModel.php';
require_once __DIR__ . '/../../Helpers/ValidationHelper.php';
require_once __DIR__ . '/../../Helpers/SessionHelper.php';
require_once __DIR__ . '/../../Helpers/AuditHelper.php';
require_once __DIR__ . '/../../Helpers/UndoHelper.php';

class CropController {
    private $model;
    private $pestModel;
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->model = new CropModel($pdo);
        $this->pestModel = new PestModel($pdo);
    }

    private function viewData() {
        return [
            'crops' => $this->model->getAllCrops(),
            'pests' => $this->pestModel->getCropPests(),
            'issueCatalog' => $this->pestModel->catalogFor('crop'),
        ];
    }

    public function index() {
        return $this->viewData();
    }

    public function add() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = $_POST;
            $fields = ['farm_id', 'name', 'planting_date'];
            $errors = ValidationHelper::validateRequired($fields, $data);

            if (!isset($errors['farm_id'])) {
                $e = ValidationHelper::exists($this->pdo, 'farms', $data['farm_id'], 'farm');
                if ($e) $errors['farm_id'] = $e;
            }

            $variety = isset($data['variety']) && trim($data['variety']) !== '' ? trim($data['variety']) : null;
            $harvest = isset($data['expected_harvest_date']) && trim($data['expected_harvest_date']) !== '' ? trim($data['expected_harvest_date']) : null;

            if ($harvest !== null && !isset($errors['planting_date']) && $harvest < $data['planting_date']) {
                $errors['expected_harvest_date'] = "Harvest date cannot be earlier than the planting date.";
            }
            $production = $this->productionFields($data, $errors);
            $errors = $production['errors'];

            if (empty($errors)) {
                try {
                    if ($this->model->createCrop((int) $data['farm_id'], trim($data['name']), $variety, $data['planting_date'], $harvest,
                        $production['field_id'], $production['area_ha'], $production['expected_yield'], $production['yield_unit'])) {
                        SessionHelper::setFlash('success', 'Crop added successfully!');
                        SessionHelper::flashCreated('Crop', $this->model->lastId(), trim($data['name']), ['Planted' => $data['planting_date']]);
                        header('Location: index.php?module=Crop&action=manage');
                        exit;
                    }
                    $errors['general'] = "Failed to add crop.";
                } catch (PDOException $e) {
                    $errors['general'] = "Could not save crop: the selected farm may no longer exist.";
                }
            }
            return array_merge(['errors' => $errors, 'data' => $data], $this->viewData());
        }
        return $this->viewData();
    }

    public function edit() {
        $id = ValidationHelper::id($_GET['id'] ?? $_POST['id'] ?? '');
        if (!$id) {
            SessionHelper::setFlash('error', 'Select a crop to edit.');
            header('Location: index.php?module=Crop&action=manage'); exit;
        }
        $crop = $this->model->getById($id);
        if (!$crop) {
            SessionHelper::setFlash('error', 'That crop no longer exists.');
            header('Location: index.php?module=Crop&action=manage'); exit;
        }
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return array_merge($this->viewData(), ['editRecord' => $crop]);
        }
        $data = $_POST;
        $errors = ValidationHelper::validateRequired(['farm_id', 'name', 'planting_date'], $data);
        if (!isset($errors['farm_id'])) {
            $e = ValidationHelper::exists($this->pdo, 'farms', $data['farm_id'], 'farm');
            if ($e) $errors['farm_id'] = $e;
        }
        $harvest = trim($data['expected_harvest_date'] ?? '') !== '' ? trim($data['expected_harvest_date']) : null;
        if ($harvest !== null && !isset($errors['planting_date']) && $harvest < $data['planting_date']) {
            $errors['expected_harvest_date'] = 'Harvest date cannot be earlier than the planting date.';
        }
        $production = $this->productionFields($data, $errors);
        $errors = $production['errors'];
        if ($errors) return array_merge($this->viewData(), ['editRecord' => array_merge($crop, $data), 'errors' => $errors]);
        try {
            $this->model->updateCrop(
                $id, (int)$data['farm_id'], trim($data['name']),
                trim($data['variety'] ?? '') !== '' ? trim($data['variety']) : null,
                $data['planting_date'], $harvest, $production['field_id'], $production['area_ha'],
                $production['expected_yield'], $production['yield_unit']
            );
            AuditHelper::log($this->pdo, 'human', 'crop_updated', 'crops', $id, $data, $_SESSION['user_id'] ?? null);
            SessionHelper::setFlash('success', 'Crop updated.');
        } catch (Throwable $e) {
            error_log('Crop update failed: ' . $e->getMessage());
            SessionHelper::setFlash('error', 'Could not update crop.');
        }
        header('Location: index.php?module=Crop&action=manage'); exit;
    }

    private function productionFields(array $data, array $errors): array
    {
        $fieldId = trim((string) ($data['field_id'] ?? ''));
        if ($fieldId !== '') {
            $fieldError = ValidationHelper::exists($this->pdo, 'fields', $fieldId, 'field');
            if ($fieldError) {
                $errors['field_id'] = $fieldError;
            } else {
                $check = $this->pdo->prepare('SELECT 1 FROM fields WHERE id = ? AND farm_id = ?');
                $check->execute([(int) $fieldId, (int) ($data['farm_id'] ?? 0)]);
                if (!$check->fetchColumn()) $errors['field_id'] = 'The field must belong to the selected farm.';
            }
        }
        $area = trim((string) ($data['area_ha'] ?? ''));
        $expected = trim((string) ($data['expected_yield'] ?? ''));
        $areaError = ValidationHelper::number($data, 'area_ha', ['label' => 'Planted area', 'positive' => true]);
        $yieldError = ValidationHelper::number($data, 'expected_yield', ['label' => 'Expected yield per hectare', 'positive' => true]);
        if ($areaError) $errors['area_ha'] = $areaError;
        if ($yieldError) $errors['expected_yield'] = $yieldError;
        $unit = trim((string) ($data['yield_unit'] ?? 'kg')) ?: 'kg';
        if (!in_array(strtolower($unit), ['kg', 'tonnes', 'litres', 'units'], true)) $errors['yield_unit'] = 'Choose kg, tonnes, litres or units.';
        return [
            'errors' => $errors,
            'field_id' => $fieldId === '' ? null : (int) $fieldId,
            'area_ha' => $area === '' ? null : (float) $area,
            'expected_yield' => $expected === '' ? null : (float) $expected,
            'yield_unit' => strtolower($unit),
        ];
    }

    /** Log a pest/disease against a crop. Folded in from the old standalone Pest module. */
    public function addPest() {
        $data = $_POST;
        $errors = [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $errors = ValidationHelper::validateRequired(['crop_id', 'pest_name', 'detected_date'], $data);

            if (!isset($errors['detected_date'])) {
                $e = ValidationHelper::dateNotFuture($data, 'detected_date', 'Detected date');
                if ($e) $errors['detected_date'] = $e;
            }

            if (!isset($errors['crop_id'])) {
                $e = ValidationHelper::exists($this->pdo, 'crops', $data['crop_id'], 'crop');
                if ($e) $errors['crop_id'] = $e;
            }

            if (empty($errors)) {
                $stmt = $this->pdo->prepare("SELECT farm_id, name FROM crops WHERE id = ?");
                $stmt->execute([(int) $data['crop_id']]);
                $crop = $stmt->fetch();

                $row = [
                    'farm_id'       => $crop ? ($crop['farm_id'] ?: null) : null,
                    'crop_id'       => (int) $data['crop_id'],
                    'pest_name'     => trim($data['pest_name']),
                    'issue_kind'    => (trim($data['issue_kind'] ?? '') !== '' ? trim($data['issue_kind']) : 'pest'),
                    'severity'      => (trim($data['severity'] ?? '') !== '' ? trim($data['severity']) : null),
                    'detected_date' => $data['detected_date'],
                    'action_taken'  => trim($data['action_taken'] ?? ''),
                ];
                try {
                    if ($this->pestModel->create($row)) {
                        SessionHelper::setFlash('success', 'Pest record added successfully!');
                        SessionHelper::flashCreated('Crop', $this->pestModel->lastId(), trim($data['pest_name']), ['Crop' => ($crop['name'] ?? '—'), 'Detected' => $data['detected_date']]);
                        header('Location: index.php?module=Crop&action=manage');
                        exit;
                    }
                    $errors['general'] = "Failed to add pest record.";
                } catch (PDOException $e) {
                    $errors['general'] = "Could not save pest record: the selected crop may no longer exist.";
                }
            }

            return array_merge(['pestErrors' => $errors, 'pestData' => $data], $this->viewData());
        }

        return $this->viewData();
    }

    public function delete() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('POST required.'); }
        $id = ValidationHelper::id($_POST['id'] ?? '');
        if (!$id) { SessionHelper::setFlash('error', 'Invalid crop.'); header('Location: index.php?module=Crop&action=manage'); exit; }
        foreach (['harvest_records' => 'crop_id', 'planting_records' => 'crop_id', 'field_history' => 'crop_id', 'health_incidents' => 'crop_id', 'spray_schedules' => 'crop_id', 'fertilizer_applications' => 'crop_id', 'chemical_applications' => 'crop_id', 'crop_growth_stages' => 'crop_id', 'seed_records' => 'crop_id'] as $table => $col) {
            try {
                $st = $this->pdo->prepare("SELECT COUNT(*) FROM {$table} WHERE {$col} = ?");
                $st->execute([$id]);
                if ((int)$st->fetchColumn() > 0) {
                    SessionHelper::setFlash('error', "Cannot delete crop: it is referenced by {$table}. Remove those records first.");
                    header('Location: index.php?module=Crop&action=manage'); exit;
                }
            } catch (PDOException $e) { /* table may not exist */ }
        }
        try {
            $st = $this->pdo->prepare("SELECT * FROM crops WHERE id = ?");
            $st->execute([$id]);
            $rowData = $st->fetch(PDO::FETCH_ASSOC) ?: [];
            $this->pdo->beginTransaction();
            $this->pdo->prepare("DELETE FROM crops WHERE id = ?")->execute([$id]);
            AuditHelper::log($this->pdo, 'human', 'crop_deleted', 'crops', $id, [], (int)($_SESSION['user_id'] ?? 0));
            $this->pdo->commit();
            require_once __DIR__ . '/../../Helpers/UndoHelper.php';
            UndoHelper::stash($this->pdo, 'crops', $rowData, 'Crop', 'index.php?module=Crop&action=manage');
            SessionHelper::setFlash('success', 'Crop deleted.');
        } catch (PDOException $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            SessionHelper::setFlash('error', 'Could not delete crop (it may be referenced elsewhere).');
        }
        header('Location: index.php?module=Crop&action=manage'); exit;
    }
    public function incidentStatus() {
        $id = ValidationHelper::id($_POST['id'] ?? $_GET['id'] ?? '');
        $status = $_POST['status'] ?? 'resolved';
        $stockItemId = ($_POST['inventory_item_id'] ?? '') !== '' ? (int) $_POST['inventory_item_id'] : null;
        $stockQty = ($_POST['quantity_used'] ?? '') !== '' ? (float) $_POST['quantity_used'] : null;
        if ($id === null) {
            SessionHelper::setFlash('error', 'Invalid or missing health incident id.');
        } elseif ($this->pestModel->setStatus($id, $status, $_POST['notes'] ?? null, $stockItemId, $stockQty)) {
            SessionHelper::setFlash('success', 'Health incident marked ' . htmlspecialchars($status) . '.');
        } else {
            SessionHelper::setFlash('error', 'Could not update the health incident, or there is not enough stock for the treatment.');
        }
        header('Location: index.php?module=Crop&action=manage');
        exit;
    }
}
?>
