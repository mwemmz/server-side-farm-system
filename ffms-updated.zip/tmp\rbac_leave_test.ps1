$ErrorActionPreference = "Continue"
$B = "https://server-side-farm-system.vercel.app"

function WebReq($label, $method, $url, $body=$null, [ref]$session=$null, $sessionVar=$null) {
    try {
        $params = @{ Uri=$url; Method=$method; UseBasicParsing=$true; MaximumRedirection=0; ErrorAction="SilentlyContinue" }
        if ($body) { $params.Body=$body; $params.ContentType="application/x-www-form-urlencoded" }
        if ($session -and $session.Value) { $params.WebSession=$session.Value }
        $r = Invoke-WebRequest @params
        $ok = $r.StatusCode -eq 200 -or $r.StatusCode -eq 302
        $icon = if ($ok) { "PASS" } else { "WARN" }
        Write-Host "[$icon] $label [HTTP $($r.StatusCode)]" -ForegroundColor $(if($ok){"Green"}else{"Yellow"})
        return $r
    } catch {
        Write-Host "[FAIL] $label : $_" -ForegroundColor Red
        return $null
    }
}

function ApiReq($label, $method, $url, $body=$null, $token=$null) {
    try {
        $h = @{ "Content-Type"="application/json" }
        if ($token) { $h.Authorization = "Bearer $token" }
        $params = @{ Uri=$url; Method=$method; Headers=$h; UseBasicParsing=$true }
        if ($body) { $params.Body=$body }
        $r = Invoke-WebRequest @params
        $j = $r.Content | ConvertFrom-Json
        $ok = $j.success -ne $false
        $icon = if ($ok) { "PASS" } else { "WARN" }
        Write-Host "[$icon] $label [HTTP $($r.StatusCode)]" -ForegroundColor $(if($ok){"Green"}else{"Yellow"})
        return $j
    } catch {
        $code = $_.Exception.Response.StatusCode.value__
        Write-Host "[FAIL] $label [HTTP $code]" -ForegroundColor Red
        return $null
    }
}

function GetCsrf($html) {
    $m = [regex]::Match($html, 'name="csrf_token"\s+value="([^"]+)"')
    return $m.Groups[1].Value
}

function LoginWeb($username, $password, [ref]$sess) {
    $loginUrl = $B + "/?module=Security&action=login"
    $page = Invoke-WebRequest -Uri $loginUrl -UseBasicParsing -SessionVariable newSess
    $sess.Value = $newSess
    $csrf = GetCsrf $page.Content
    $body = "username=" + $username + "&password=" + $password + "&csrf_token=" + [Uri]::EscapeDataString($csrf)
    $r = Invoke-WebRequest -Uri $loginUrl -Method POST -Body $body -ContentType "application/x-www-form-urlencoded" -WebSession $newSess -UseBasicParsing -MaximumRedirection 0 -ErrorAction SilentlyContinue
    # follow the redirect to establish session
    if ($r.StatusCode -eq 302) {
        $dest = $B + "/index.php?module=Dashboard"
        Invoke-WebRequest -Uri $dest -UseBasicParsing -WebSession $newSess | Out-Null
    }
    return $r.StatusCode -eq 302
}

# ============================================================
Write-Host "" 
Write-Host "=== STEP 1: Admin API login ===" -ForegroundColor Cyan
$auth = ApiReq "Admin JWT login" POST "$B/api/v1/auth/token" '{"username":"admin","password":"admin123"}'
$adminToken = $auth.data.token
Write-Host "   Role: $($auth.data.user.role) | ID: $($auth.data.user.id)"

# ============================================================
Write-Host ""
Write-Host "=== STEP 2: Create manager + worker accounts ===" -ForegroundColor Cyan
$adminSess = $null
$loggedIn = LoginWeb "admin" "admin123" ([ref]$adminSess)
Write-Host "   Admin web session: $(if($loggedIn){'PASS'}else{'FAIL'})" -ForegroundColor $(if($loggedIn){"Green"}else{"Red"})

$usersUrl = $B + "/?module=Security&action=users"

# Create manager
$p1 = Invoke-WebRequest -Uri $usersUrl -UseBasicParsing -WebSession $adminSess
$c1 = GetCsrf $p1.Content
$b1 = "username=farm_manager&email=manager%40test.farm&password=Manager123!&role=manager&csrf_token=" + [Uri]::EscapeDataString($c1)
$r1 = Invoke-WebRequest -Uri $usersUrl -Method POST -Body $b1 -ContentType "application/x-www-form-urlencoded" -WebSession $adminSess -UseBasicParsing -MaximumRedirection 0 -ErrorAction SilentlyContinue
$mgr_ok = $r1.StatusCode -eq 302 -or $r1.Content -match "created|already taken"
Write-Host "   Create manager (farm_manager): $(if($mgr_ok){'PASS ✓'}else{'CHECK'})" -ForegroundColor $(if($mgr_ok){"Green"}else{"Yellow"})

# Create worker
$p2 = Invoke-WebRequest -Uri $usersUrl -UseBasicParsing -WebSession $adminSess
$c2 = GetCsrf $p2.Content
$b2 = "username=farm_worker&email=worker%40test.farm&password=Worker123!&role=worker&csrf_token=" + [Uri]::EscapeDataString($c2)
$r2 = Invoke-WebRequest -Uri $usersUrl -Method POST -Body $b2 -ContentType "application/x-www-form-urlencoded" -WebSession $adminSess -UseBasicParsing -MaximumRedirection 0 -ErrorAction SilentlyContinue
$wkr_ok = $r2.StatusCode -eq 302 -or $r2.Content -match "created|already taken"
Write-Host "   Create worker (farm_worker): $(if($wkr_ok){'PASS ✓'}else{'CHECK'})" -ForegroundColor $(if($wkr_ok){"Green"}else{"Yellow"})

# ============================================================
Write-Host ""
Write-Host "=== STEP 3: Login as manager and worker ===" -ForegroundColor Cyan
$mgrAuth = ApiReq "Manager JWT login" POST "$B/api/v1/auth/token" '{"username":"farm_manager","password":"Manager123!"}'
$mgrToken = $mgrAuth.data.token
Write-Host "   Manager role: $($mgrAuth.data.user.role)"

$wkrAuth = ApiReq "Worker JWT login" POST "$B/api/v1/auth/token" '{"username":"farm_worker","password":"Worker123!"}'
$wkrToken = $wkrAuth.data.token
Write-Host "   Worker role: $($wkrAuth.data.user.role)"

# ============================================================
Write-Host ""
Write-Host "=== STEP 4: API RBAC checks ===" -ForegroundColor Cyan

Write-Host "  [Manager permissions]" -ForegroundColor Magenta
ApiReq "Manager: GET intranet conversations" GET "$B/api/v1/intranet/conversations" -token $mgrToken | Out-Null
ApiReq "Manager: GET extranet connections" GET "$B/api/v1/extranet/connections" -token $mgrToken | Out-Null
ApiReq "Manager: GET farm search" GET "$B/api/v1/extranet/farms/search?q=" -token $mgrToken | Out-Null

Write-Host "  [Worker permissions]" -ForegroundColor Magenta
ApiReq "Worker: GET intranet conversations (allowed)" GET "$B/api/v1/intranet/conversations" -token $wkrToken | Out-Null
ApiReq "Worker: GET extranet/farms/search (NOT in worker perms)" GET "$B/api/v1/extranet/farms/search?q=" -token $wkrToken | Out-Null

# ============================================================
Write-Host ""
Write-Host "=== STEP 5: Create employee records ===" -ForegroundColor Cyan
$empUrl = $B + "/?module=Labour&action=add&subsection=employees"

# Manager employee
$ep1 = Invoke-WebRequest -Uri ($B + "/?module=Labour&subsection=employees") -UseBasicParsing -WebSession $adminSess
$ec1 = GetCsrf $ep1.Content
$eb1 = "name=farm_manager&job_title=Farm+Manager&employment_status=active&contract_type=permanent&pay_type=monthly&monthly_salary=5000&hire_date=2024-01-01&csrf_token=" + [Uri]::EscapeDataString($ec1)
$er1 = Invoke-WebRequest -Uri $empUrl -Method POST -Body $eb1 -ContentType "application/x-www-form-urlencoded" -WebSession $adminSess -UseBasicParsing -MaximumRedirection 0 -ErrorAction SilentlyContinue
Write-Host "   Manager employee record: HTTP $($er1.StatusCode) $(if($er1.StatusCode -eq 302){'PASS ✓'}else{'CHECK'})" -ForegroundColor $(if($er1.StatusCode -eq 302){"Green"}else{"Yellow"})

# Worker employee
$ep2 = Invoke-WebRequest -Uri ($B + "/?module=Labour&subsection=employees") -UseBasicParsing -WebSession $adminSess
$ec2 = GetCsrf $ep2.Content
$eb2 = "name=farm_worker&job_title=Farm+Worker&employment_status=active&contract_type=permanent&pay_type=daily&daily_rate=150&hire_date=2024-03-01&csrf_token=" + [Uri]::EscapeDataString($ec2)
$er2 = Invoke-WebRequest -Uri $empUrl -Method POST -Body $eb2 -ContentType "application/x-www-form-urlencoded" -WebSession $adminSess -UseBasicParsing -MaximumRedirection 0 -ErrorAction SilentlyContinue
Write-Host "   Worker employee record: HTTP $($er2.StatusCode) $(if($er2.StatusCode -eq 302){'PASS ✓'}else{'CHECK'})" -ForegroundColor $(if($er2.StatusCode -eq 302){"Green"}else{"Yellow"})

# ============================================================
Write-Host ""
Write-Host "=== STEP 6: Worker logs in web + views leave page ===" -ForegroundColor Cyan
$workerSess = $null
$wLoggedIn = LoginWeb "farm_worker" "Worker123!" ([ref]$workerSess)
Write-Host "   Worker web login: $(if($wLoggedIn){'PASS ✓'}else{'FAIL ✗'})" -ForegroundColor $(if($wLoggedIn){"Green"}else{"Red"})

$wLeaveUrl = $B + "/?module=Labour&subsection=leave"
$wLP = Invoke-WebRequest -Uri $wLeaveUrl -UseBasicParsing -WebSession $workerSess
$hasApproveBtn = $wLP.Content -match "action=approve"
$hasWorkerView = $wLP.Content -match "My Leave Requests|Request Leave"
Write-Host "   Worker sees 'My Leave Requests': $(if($hasWorkerView){'PASS ✓'}else{'FAIL ✗'})" -ForegroundColor $(if($hasWorkerView){"Green"}else{"Red"})
Write-Host "   Worker sees Approve button: $(if(!$hasApproveBtn){'PASS ✓ (correctly hidden)'}else{'FAIL ✗ (should be hidden)'})" -ForegroundColor $(if(!$hasApproveBtn){"Green"}else{"Red"})

# Worker submits leave
$wCsrf = GetCsrf $wLP.Content
$today = (Get-Date).ToString("yyyy-MM-dd")
$nextWk = (Get-Date).AddDays(5).ToString("yyyy-MM-dd")
$leaveBody = "leave_type=annual&start_date=" + $today + "&end_date=" + $nextWk + "&days=5&reason=Family+vacation&csrf_token=" + [Uri]::EscapeDataString($wCsrf)
$leaveResp = Invoke-WebRequest -Uri ($B + "/?module=Labour&action=add&subsection=leave") -Method POST -Body $leaveBody -ContentType "application/x-www-form-urlencoded" -WebSession $workerSess -UseBasicParsing -MaximumRedirection 0 -ErrorAction SilentlyContinue
Write-Host "   Worker submits leave request: HTTP $($leaveResp.StatusCode) $(if($leaveResp.StatusCode -eq 302){'PASS ✓ (submitted and redirected)'}else{'CHECK'})" -ForegroundColor $(if($leaveResp.StatusCode -eq 302){"Green"}else{"Yellow"})

# ============================================================
Write-Host ""
Write-Host "=== STEP 7: Worker tries to approve leave (should be blocked) ===" -ForegroundColor Cyan
$wLP2 = Invoke-WebRequest -Uri $wLeaveUrl -UseBasicParsing -WebSession $workerSess
$wCsrf2 = GetCsrf $wLP2.Content
$blockBody = "csrf_token=" + [Uri]::EscapeDataString($wCsrf2)
$blockUrl = $B + "/?module=Labour&action=approve&subsection=leave&id=1"
$blockR = Invoke-WebRequest -Uri $blockUrl -Method POST -Body $blockBody -ContentType "application/x-www-form-urlencoded" -WebSession $workerSess -UseBasicParsing -MaximumRedirection 5 -ErrorAction SilentlyContinue
$blocked = $blockR.Content -match "Only managers|Access denied|not.*allowed|error" -or $blockR.StatusCode -eq 403
Write-Host "   Worker blocked from approving leave: $(if($blocked){'PASS ✓ (blocked)'}else{'CHECK - HTTP ' + $blockR.StatusCode})" -ForegroundColor $(if($blocked){"Green"}else{"Yellow"})

# ============================================================
Write-Host ""
Write-Host "=== STEP 8: Manager views pending approvals ===" -ForegroundColor Cyan
$mgrSess = $null
$mLoggedIn = LoginWeb "farm_manager" "Manager123!" ([ref]$mgrSess)
Write-Host "   Manager web login: $(if($mLoggedIn){'PASS ✓'}else{'FAIL ✗'})" -ForegroundColor $(if($mLoggedIn){"Green"}else{"Red"})

$mLeaveUrl = $B + "/?module=Labour&subsection=leave"
$mLP = Invoke-WebRequest -Uri $mLeaveUrl -UseBasicParsing -WebSession $mgrSess
$mHasPending = $mLP.Content -match "Pending Approvals"
$mHasApprove = $mLP.Content -match "action=approve"
Write-Host "   Manager sees 'Pending Approvals' section: $(if($mHasPending){'PASS ✓'}else{'FAIL ✗'})" -ForegroundColor $(if($mHasPending){"Green"}else{"Red"})
Write-Host "   Manager sees Approve buttons: $(if($mHasApprove){'PASS ✓'}else{'INFO - no pending requests yet'})" -ForegroundColor $(if($mHasApprove){"Green"}else{"Yellow"})

# Extract pending leave ID
$pendingMatch = [regex]::Match($mLP.Content, "action=approve&subsection=leave&id=(\d+)")
$pendingId = $pendingMatch.Groups[1].Value
Write-Host "   Pending leave ID found: $(if($pendingId){"#$pendingId PASS ✓"}else{'none - submit a leave request first'})" -ForegroundColor $(if($pendingId){"Green"}else{"Yellow"})

# Manager approves
if ($pendingId) {
    $mCsrf = GetCsrf $mLP.Content
    $appBody = "csrf_token=" + [Uri]::EscapeDataString($mCsrf)
    $appUrl = $B + "/?module=Labour&action=approve&subsection=leave&id=" + $pendingId
    $appR = Invoke-WebRequest -Uri $appUrl -Method POST -Body $appBody -ContentType "application/x-www-form-urlencoded" -WebSession $mgrSess -UseBasicParsing -MaximumRedirection 5 -ErrorAction SilentlyContinue
    $approved = $appR.StatusCode -eq 200 -and ($appR.Content -match "approved|success|Leave Management")
    Write-Host "   Manager approves leave #${pendingId}: HTTP $($appR.StatusCode) $(if($approved){'PASS ✓'}else{'CHECK'})" -ForegroundColor $(if($approved){"Green"}else{"Yellow"})

    # Verify removed from pending
    $mLP2 = Invoke-WebRequest -Uri $mLeaveUrl -UseBasicParsing -WebSession $mgrSess
    $stillThere = $mLP2.Content -match ("action=approve&subsection=leave&id=" + $pendingId)
    Write-Host "   Leave #${pendingId} removed from pending: $(if(!$stillThere){'PASS ✓'}else{'FAIL ✗ still listed'})" -ForegroundColor $(if(!$stillThere){"Green"}else{"Red"})
}

# ============================================================
Write-Host ""
Write-Host "=== STEP 9: Worker sees approved status ===" -ForegroundColor Cyan
$wLP3 = Invoke-WebRequest -Uri $wLeaveUrl -UseBasicParsing -WebSession $workerSess
$workerSeesApproved = $wLP3.Content -match "approved|Approved"
Write-Host "   Worker sees approved status: $(if($workerSeesApproved){'PASS ✓'}else{'INFO - may need employee ID linked to username'})" -ForegroundColor $(if($workerSeesApproved){"Green"}else{"Yellow"})

# ============================================================
Write-Host ""
Write-Host "=== STEP 10: Sidebar RBAC visibility ===" -ForegroundColor Cyan

# Worker dashboard
$wDash = Invoke-WebRequest -Uri ($B + "/?module=Dashboard") -UseBasicParsing -WebSession $workerSess
Write-Host "   Worker does NOT see Finance: $(if($wDash.Content -notmatch 'href.*module=Finance[^A-Za-z]'){'PASS ✓'}else{'FAIL ✗'})" -ForegroundColor $(if($wDash.Content -notmatch 'href.*module=Finance[^A-Za-z]'){"Green"}else{"Red"})
Write-Host "   Worker does NOT see Users link: $(if($wDash.Content -notmatch 'action=users'){'PASS ✓'}else{'FAIL ✗'})" -ForegroundColor $(if($wDash.Content -notmatch 'action=users'){"Green"}else{"Red"})
Write-Host "   Worker DOES see Notifications: $(if($wDash.Content -match 'module=Notifications'){'PASS ✓'}else{'INFO'})" -ForegroundColor $(if($wDash.Content -match 'module=Notifications'){"Green"}else{"Yellow"})
Write-Host "   Worker DOES see Marketplace: $(if($wDash.Content -match 'module=Marketplace'){'PASS ✓'}else{'INFO'})" -ForegroundColor $(if($wDash.Content -match 'module=Marketplace'){"Green"}else{"Yellow"})

# Manager dashboard
$mDash = Invoke-WebRequest -Uri ($B + "/?module=Dashboard") -UseBasicParsing -WebSession $mgrSess
Write-Host "   Manager does NOT see Users link: $(if($mDash.Content -notmatch 'action=users'){'PASS ✓'}else{'FAIL ✗'})" -ForegroundColor $(if($mDash.Content -notmatch 'action=users'){"Green"}else{"Red"})
Write-Host "   Manager DOES see Labour: $(if($mDash.Content -match 'module=Labour'){'PASS ✓'}else{'INFO - not in manager menu'})" -ForegroundColor $(if($mDash.Content -match 'module=Labour'){"Green"}else{"Yellow"})
Write-Host "   Manager DOES see Communications: $(if($mDash.Content -match 'module=Communications'){'PASS ✓'}else{'INFO'})" -ForegroundColor $(if($mDash.Content -match 'module=Communications'){"Green"}else{"Yellow"})

# Worker tries to access Finance directly (should be blocked server-side)
$finTest = Invoke-WebRequest -Uri ($B + "/?module=Finance") -UseBasicParsing -WebSession $workerSess
$finBlocked = $finTest.Content -match "Access Denied"
Write-Host "   Worker blocked from Finance (direct URL): $(if($finBlocked){'PASS ✓'}else{'FAIL ✗ — page loaded'})" -ForegroundColor $(if($finBlocked){"Green"}else{"Red"})

# Worker tries to access Security/Users directly
$secTest = Invoke-WebRequest -Uri ($B + "/?module=Security&action=users") -UseBasicParsing -WebSession $workerSess
$secBlocked = $secTest.StatusCode -eq 403 -or $secTest.Content -match "Access Denied|403"
Write-Host "   Worker blocked from Security/Users (direct URL): $(if($secBlocked){'PASS ✓'}else{'FAIL ✗'})" -ForegroundColor $(if($secBlocked){"Green"}else{"Red"})

Write-Host ""
Write-Host "=== ALL TESTS COMPLETE ===" -ForegroundColor Cyan
