@echo off
setlocal enabledelayedexpansion
set B=https://server-side-farm-system.vercel.app
set CA=%TEMP%\ffms_admin.txt
set CM=%TEMP%\ffms_mgr.txt
set CW=%TEMP%\ffms_wkr.txt
set PASS=0
set FAIL=0

del %CA% %CM% %CW% 2>nul

echo.
echo === STEP 1: Admin JWT login ===
curl -s -X POST "%B%/api/v1/auth/token" -H "Content-Type: application/json" -d "{\"username\":\"admin\",\"password\":\"admin123\"}" > %TEMP%\ffms_out.txt
findstr /i "\"admin\"" %TEMP%\ffms_out.txt >nul && (echo [PASS] Admin JWT login & set /a PASS+=1) || (echo [FAIL] Admin JWT login & set /a FAIL+=1)

REM Extract token
for /f "tokens=2 delims=:," %%a in ('findstr "\"token\"" %TEMP%\ffms_out.txt') do set ADMIN_TOKEN=%%a
set ADMIN_TOKEN=%ADMIN_TOKEN: =%
set ADMIN_TOKEN=%ADMIN_TOKEN:"=%

echo.
echo === STEP 2: Admin web login ===
curl -s -c %CA% -b %CA% "%B%/?module=Security&action=login" > %TEMP%\ffms_login.txt
REM extract CSRF
for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_login.txt') do set CSRF=%%a
set CSRF=%CSRF:~1,-1%
set CSRF=%CSRF: =%
for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a

curl -s -w "%%{http_code}" -c %CA% -b %CA% -X POST "%B%/?module=Security&action=login" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "username=admin&password=admin123&csrf_token=%CSRF_ENC%" > %TEMP%\ffms_code.txt
set /p HTTP_CODE=<%TEMP%\ffms_code.txt
echo HTTP %HTTP_CODE%
if "%HTTP_CODE%"=="302" (echo [PASS] Admin web login & set /a PASS+=1) else (echo [FAIL] Admin web login & set /a FAIL+=1)

echo.
echo === STEP 3: Create manager + worker ===
curl -s -c %CA% -b %CA% "%B%/?module=Security&action=users" > %TEMP%\ffms_users.txt
for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_users.txt') do set CSRF=%%a
set CSRF=%CSRF:~1,-1%
set CSRF=%CSRF: =%
for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a

curl -s -w "%%{http_code}" -c %CA% -b %CA% -X POST "%B%/?module=Security&action=users" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "username=farm_manager&email=manager%%40test.farm&password=Manager123%%21&role=manager&csrf_token=%CSRF_ENC%" > %TEMP%\ffms_code.txt
set /p HTTP_CODE=<%TEMP%\ffms_code.txt
if "%HTTP_CODE%"=="302" (echo [PASS] Create farm_manager user & set /a PASS+=1) else (
  findstr /i "created\|already" %TEMP%\ffms_code.txt >nul && (echo [PASS] Create farm_manager user ^(already exists^) & set /a PASS+=1) || (echo [WARN] Create farm_manager: HTTP %HTTP_CODE%)
)

curl -s -c %CA% -b %CA% "%B%/?module=Security&action=users" > %TEMP%\ffms_users.txt
for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_users.txt') do set CSRF=%%a
set CSRF=%CSRF:~1,-1%
set CSRF=%CSRF: =%
for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a

curl -s -w "%%{http_code}" -c %CA% -b %CA% -X POST "%B%/?module=Security&action=users" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "username=farm_worker&email=worker%%40test.farm&password=Worker123%%21&role=worker&csrf_token=%CSRF_ENC%" > %TEMP%\ffms_code.txt
set /p HTTP_CODE=<%TEMP%\ffms_code.txt
if "%HTTP_CODE%"=="302" (echo [PASS] Create farm_worker user & set /a PASS+=1) else (echo [WARN] Create farm_worker: HTTP %HTTP_CODE%)

echo.
echo === STEP 4: JWT logins for new accounts ===
curl -s -X POST "%B%/api/v1/auth/token" -H "Content-Type: application/json" -d "{\"username\":\"farm_manager\",\"password\":\"Manager123!\"}" > %TEMP%\ffms_mgr_auth.txt
findstr /i "\"manager\"" %TEMP%\ffms_mgr_auth.txt >nul && (echo [PASS] Manager JWT login - role=manager & set /a PASS+=1) || (echo [FAIL] Manager JWT login & set /a FAIL+=1)
for /f "tokens=2 delims=:," %%a in ('findstr "\"token\"" %TEMP%\ffms_mgr_auth.txt') do set MGR_TOKEN=%%a
set MGR_TOKEN=%MGR_TOKEN: =%
set MGR_TOKEN=%MGR_TOKEN:"=%

curl -s -X POST "%B%/api/v1/auth/token" -H "Content-Type: application/json" -d "{\"username\":\"farm_worker\",\"password\":\"Worker123!\"}" > %TEMP%\ffms_wkr_auth.txt
findstr /i "\"worker\"" %TEMP%\ffms_wkr_auth.txt >nul && (echo [PASS] Worker JWT login - role=worker & set /a PASS+=1) || (echo [FAIL] Worker JWT login & set /a FAIL+=1)
for /f "tokens=2 delims=:," %%a in ('findstr "\"token\"" %TEMP%\ffms_wkr_auth.txt') do set WKR_TOKEN=%%a
set WKR_TOKEN=%WKR_TOKEN: =%
set WKR_TOKEN=%WKR_TOKEN:"=%

echo.
echo === STEP 5: API RBAC checks ===
curl -s "%B%/api/v1/intranet/conversations" -H "Authorization: Bearer %MGR_TOKEN%" > %TEMP%\ffms_out.txt
findstr /i "\"success\":true" %TEMP%\ffms_out.txt >nul && (echo [PASS] Manager: intranet conversations & set /a PASS+=1) || (echo [FAIL] Manager: intranet conversations & set /a FAIL+=1)

curl -s "%B%/api/v1/extranet/connections" -H "Authorization: Bearer %MGR_TOKEN%" > %TEMP%\ffms_out.txt
findstr /i "\"success\":true" %TEMP%\ffms_out.txt >nul && (echo [PASS] Manager: extranet connections & set /a PASS+=1) || (echo [FAIL] Manager: extranet connections & set /a FAIL+=1)

curl -s "%B%/api/v1/extranet/farms/search?q=" -H "Authorization: Bearer %MGR_TOKEN%" > %TEMP%\ffms_out.txt
findstr /i "\"success\":true" %TEMP%\ffms_out.txt >nul && (echo [PASS] Manager: farm search & set /a PASS+=1) || (echo [FAIL] Manager: farm search & set /a FAIL+=1)

curl -s "%B%/api/v1/intranet/conversations" -H "Authorization: Bearer %WKR_TOKEN%" > %TEMP%\ffms_out.txt
findstr /i "\"success\":true" %TEMP%\ffms_out.txt >nul && (echo [PASS] Worker: intranet conversations allowed & set /a PASS+=1) || (echo [FAIL] Worker: intranet conversations & set /a FAIL+=1)

curl -s "%B%/api/v1/extranet/farms/search?q=" -H "Authorization: Bearer %WKR_TOKEN%" > %TEMP%\ffms_out.txt
findstr /i "\"success\":false" %TEMP%\ffms_out.txt >nul && (echo [PASS] Worker: farm search BLOCKED ^(no connections.read^) & set /a PASS+=1) || (echo [FAIL] Worker: should be blocked from farm search & set /a FAIL+=1)

echo.
echo === STEP 6: Create employee records ===
curl -s -c %CA% -b %CA% "%B%/?module=Labour&subsection=employees" > %TEMP%\ffms_emp.txt
for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_emp.txt') do set CSRF=%%a
set CSRF=%CSRF:~1,-1%
set CSRF=%CSRF: =%
for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a

curl -s -w "%%{http_code}" -c %CA% -b %CA% -X POST "%B%/?module=Labour&action=add&subsection=employees" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "name=farm_manager&job_title=Farm+Manager&employment_status=active&contract_type=permanent&pay_type=monthly&monthly_salary=5000&hire_date=2024-01-01&csrf_token=%CSRF_ENC%" > %TEMP%\ffms_code.txt
set /p HTTP_CODE=<%TEMP%\ffms_code.txt
if "%HTTP_CODE%"=="302" (echo [PASS] Employee record: farm_manager & set /a PASS+=1) else (echo [WARN] Employee record manager: HTTP %HTTP_CODE%)

curl -s -c %CA% -b %CA% "%B%/?module=Labour&subsection=employees" > %TEMP%\ffms_emp.txt
for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_emp.txt') do set CSRF=%%a
set CSRF=%CSRF:~1,-1%
set CSRF=%CSRF: =%
for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a

curl -s -w "%%{http_code}" -c %CA% -b %CA% -X POST "%B%/?module=Labour&action=add&subsection=employees" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "name=farm_worker&job_title=Farm+Worker&employment_status=active&contract_type=permanent&pay_type=daily&daily_rate=150&hire_date=2024-03-01&csrf_token=%CSRF_ENC%" > %TEMP%\ffms_code.txt
set /p HTTP_CODE=<%TEMP%\ffms_code.txt
if "%HTTP_CODE%"=="302" (echo [PASS] Employee record: farm_worker & set /a PASS+=1) else (echo [WARN] Employee record worker: HTTP %HTTP_CODE%)

echo.
echo === STEP 7: Worker web login + leave page ===
curl -s -c %CW% -b %CW% "%B%/?module=Security&action=login" > %TEMP%\ffms_wlogin.txt
for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_wlogin.txt') do set CSRF=%%a
set CSRF=%CSRF:~1,-1%
set CSRF=%CSRF: =%
for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a

curl -s -w "%%{http_code}" -c %CW% -b %CW% -X POST "%B%/?module=Security&action=login" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "username=farm_worker&password=Worker123%%21&csrf_token=%CSRF_ENC%" > %TEMP%\ffms_code.txt
set /p HTTP_CODE=<%TEMP%\ffms_code.txt
if "%HTTP_CODE%"=="302" (echo [PASS] Worker web login & set /a PASS+=1) else (echo [FAIL] Worker web login: HTTP %HTTP_CODE% & set /a FAIL+=1)

curl -s -c %CW% -b %CW% -L "%B%/?module=Dashboard" > nul

curl -s -c %CW% -b %CW% "%B%/?module=Labour&subsection=leave" > %TEMP%\ffms_wleave.txt
findstr /i "My Leave Requests\|Request Leave" %TEMP%\ffms_wleave.txt >nul && (echo [PASS] Worker sees worker leave view ^(not HR view^) & set /a PASS+=1) || (echo [FAIL] Worker leave view missing & set /a FAIL+=1)
findstr /i "action=approve" %TEMP%\ffms_wleave.txt >nul && (echo [FAIL] Worker sees Approve button ^(SHOULD be hidden^) & set /a FAIL+=1) || (echo [PASS] Worker does NOT see Approve buttons & set /a PASS+=1)

REM Worker submits leave
for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_wleave.txt') do set CSRF=%%a
set CSRF=%CSRF:~1,-1%
set CSRF=%CSRF: =%
for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a
for /f "tokens=1" %%a in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd"') do set TODAY=%%a
for /f "tokens=1" %%a in ('powershell -NoProfile -Command "(Get-Date).AddDays(5).ToString(\"yyyy-MM-dd\")"') do set ENDD=%%a

curl -s -w "%%{http_code}" -c %CW% -b %CW% -X POST "%B%/?module=Labour&action=add&subsection=leave" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "leave_type=annual&start_date=%TODAY%&end_date=%ENDD%&days=5&reason=Family+vacation&csrf_token=%CSRF_ENC%" > %TEMP%\ffms_code.txt
set /p HTTP_CODE=<%TEMP%\ffms_code.txt
if "%HTTP_CODE%"=="302" (echo [PASS] Worker submits leave request & set /a PASS+=1) else (echo [WARN] Worker leave submit: HTTP %HTTP_CODE%)

echo.
echo === STEP 8: Worker tries to approve ^(RBAC block^) ===
curl -s -c %CW% -b %CW% "%B%/?module=Labour&subsection=leave" > %TEMP%\ffms_wleave2.txt
for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_wleave2.txt') do set CSRF=%%a
set CSRF=%CSRF:~1,-1%
set CSRF=%CSRF: =%
for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a

curl -s -c %CW% -b %CW% -X POST -L "%B%/?module=Labour&action=approve&subsection=leave&id=1" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "csrf_token=%CSRF_ENC%" > %TEMP%\ffms_block.txt
findstr /i "Only managers\|Access denied\|error\|not.*allowed" %TEMP%\ffms_block.txt >nul && (echo [PASS] Worker blocked from approving leave & set /a PASS+=1) || (echo [WARN] Worker approve block -- check manually)

echo.
echo === STEP 9: Manager web login + view pending ===
curl -s -c %CM% -b %CM% "%B%/?module=Security&action=login" > %TEMP%\ffms_mlogin.txt
for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_mlogin.txt') do set CSRF=%%a
set CSRF=%CSRF:~1,-1%
set CSRF=%CSRF: =%
for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a

curl -s -w "%%{http_code}" -c %CM% -b %CM% -X POST "%B%/?module=Security&action=login" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "username=farm_manager&password=Manager123%%21&csrf_token=%CSRF_ENC%" > %TEMP%\ffms_code.txt
set /p HTTP_CODE=<%TEMP%\ffms_code.txt
if "%HTTP_CODE%"=="302" (echo [PASS] Manager web login & set /a PASS+=1) else (echo [FAIL] Manager web login: HTTP %HTTP_CODE% & set /a FAIL+=1)

curl -s -c %CM% -b %CM% -L "%B%/?module=Dashboard" > nul
curl -s -c %CM% -b %CM% "%B%/?module=Labour&subsection=leave" > %TEMP%\ffms_mleave.txt

findstr /i "Pending Approvals" %TEMP%\ffms_mleave.txt >nul && (echo [PASS] Manager sees Pending Approvals ^(HR view^) & set /a PASS+=1) || (echo [FAIL] Manager missing HR view & set /a FAIL+=1)
findstr /i "action=approve" %TEMP%\ffms_mleave.txt >nul && (echo [PASS] Manager sees Approve buttons & set /a PASS+=1) || (echo [WARN] No pending leave to approve yet)

REM Extract pending leave ID using PowerShell
for /f %%a in ('powershell -NoProfile -Command "Select-String -Path '%TEMP%\ffms_mleave.txt' -Pattern 'action=approve&subsection=leave&id=(\d+)' | ForEach-Object { $_.Matches.Groups[1].Value } | Select-Object -First 1"') do set LEAVE_ID=%%a

if defined LEAVE_ID (
    echo [PASS] Found pending leave ID #%LEAVE_ID% in manager view
    set /a PASS+=1

    REM Get fresh CSRF
    for /f "tokens=2 delims=value=" %%a in ('findstr /i "csrf_token" %TEMP%\ffms_mleave.txt') do set CSRF=%%a
    set CSRF=%CSRF:~1,-1%
    set CSRF=%CSRF: =%
    for /f %%a in ('powershell -NoProfile -Command "[Uri]::EscapeDataString('%CSRF%')"') do set CSRF_ENC=%%a

    curl -s -c %CM% -b %CM% -L -X POST "%B%/?module=Labour&action=approve&subsection=leave&id=%LEAVE_ID%" -H "Content-Type: application/x-www-form-urlencoded" --data-raw "csrf_token=%CSRF_ENC%" > %TEMP%\ffms_approve.txt
    findstr /i "Leave Management\|success\|approved" %TEMP%\ffms_approve.txt >nul && (echo [PASS] Manager approves leave #%LEAVE_ID% & set /a PASS+=1) || (echo [WARN] Approve response -- check manually)

    REM Verify removed from pending
    curl -s -c %CM% -b %CM% "%B%/?module=Labour&subsection=leave" > %TEMP%\ffms_mleave2.txt
    findstr /i "action=approve&subsection=leave&id=%LEAVE_ID%" %TEMP%\ffms_mleave2.txt >nul && (echo [FAIL] Leave #%LEAVE_ID% still in pending & set /a FAIL+=1) || (echo [PASS] Leave #%LEAVE_ID% removed from pending & set /a PASS+=1)
) else (
    echo [WARN] No pending leave ID found -- submit a leave first
)

echo.
echo === STEP 10: Worker sees approved status ===
curl -s -c %CW% -b %CW% "%B%/?module=Labour&subsection=leave" > %TEMP%\ffms_wleave3.txt
findstr /i "approved\|Approved" %TEMP%\ffms_wleave3.txt >nul && (echo [PASS] Worker sees approved status on request & set /a PASS+=1) || (echo [WARN] Worker approved status -- may need employee ID linked)

echo.
echo === STEP 11: Sidebar RBAC ===
curl -s -c %CW% -b %CW% -L "%B%/?module=Dashboard" > %TEMP%\ffms_wdash.txt
findstr /i "module=Finance" %TEMP%\ffms_wdash.txt >nul && (echo [FAIL] Worker sees Finance in sidebar & set /a FAIL+=1) || (echo [PASS] Worker: Finance NOT in sidebar & set /a PASS+=1)
findstr /i "action=users" %TEMP%\ffms_wdash.txt >nul && (echo [FAIL] Worker sees Users link & set /a FAIL+=1) || (echo [PASS] Worker: Users NOT in sidebar & set /a PASS+=1)
findstr /i "module=Marketplace" %TEMP%\ffms_wdash.txt >nul && (echo [PASS] Worker: Marketplace IS in sidebar & set /a PASS+=1) || (echo [WARN] Worker: Marketplace not in sidebar)
findstr /i "module=Notifications" %TEMP%\ffms_wdash.txt >nul && (echo [PASS] Worker: Notifications IS in sidebar & set /a PASS+=1) || (echo [WARN] Worker: Notifications not in sidebar)

curl -s -c %CM% -b %CM% -L "%B%/?module=Dashboard" > %TEMP%\ffms_mdash.txt
findstr /i "action=users" %TEMP%\ffms_mdash.txt >nul && (echo [FAIL] Manager sees Users link & set /a FAIL+=1) || (echo [PASS] Manager: Users NOT in sidebar & set /a PASS+=1)
findstr /i "module=Labour" %TEMP%\ffms_mdash.txt >nul && (echo [PASS] Manager: Labour IS in sidebar & set /a PASS+=1) || (echo [WARN] Manager: Labour not in sidebar)
findstr /i "module=Communications" %TEMP%\ffms_mdash.txt >nul && (echo [PASS] Manager: Communications IS in sidebar & set /a PASS+=1) || (echo [WARN] Manager: Communications not in sidebar)

REM Direct URL access blocks
curl -s -c %CW% -b %CW% -L "%B%/?module=Finance" > %TEMP%\ffms_wfin.txt
findstr /i "Access Denied" %TEMP%\ffms_wfin.txt >nul && (echo [PASS] Worker blocked from Finance ^(direct URL^) & set /a PASS+=1) || (echo [FAIL] Worker accessed Finance directly & set /a FAIL+=1)

curl -s -c %CW% -b %CW% -L "%B%/?module=Security&action=users" > %TEMP%\ffms_wsec.txt
findstr /i "Access Denied\|403" %TEMP%\ffms_wsec.txt >nul && (echo [PASS] Worker blocked from Security/Users ^(direct URL^) & set /a PASS+=1) || (echo [FAIL] Worker accessed Security/Users directly & set /a FAIL+=1)

echo.
echo ============================================
echo   RESULTS: %PASS% PASSED / %FAIL% FAILED
echo ============================================
endlocal
