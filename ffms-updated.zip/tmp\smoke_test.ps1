$ErrorActionPreference = "Continue"
$B = "https://server-side-farm-system.vercel.app"

# Get token
$authJson = '{"username":"admin","password":"admin123"}'
$authResp = Invoke-WebRequest -Uri "$B/api/v1/auth/token" -Method POST -ContentType "application/json" -Body $authJson -UseBasicParsing
$TOKEN = ($authResp.Content | ConvertFrom-Json).data.token
Write-Host "AUTH: token acquired ($($TOKEN.Length) chars)" -ForegroundColor Green

function Hit([string]$label, [string]$method, [string]$url, [string]$body = "") {
    try {
        $params = @{
            Uri             = $url
            Method          = $method
            Headers         = @{ Authorization = "Bearer $TOKEN" }
            UseBasicParsing = $true
        }
        if ($body -ne "") {
            $params["Body"]        = $body
            $params["ContentType"] = "application/json"
        }
        $resp = Invoke-WebRequest @params
        $j    = $resp.Content | ConvertFrom-Json
        $icon = if ($j.success) { "PASS" } else { "WARN" }
        $snippet = $resp.Content.Substring(0, [Math]::Min(150, $resp.Content.Length))
        Write-Host "[$icon] $label [HTTP $($resp.StatusCode)]" -ForegroundColor $(if ($j.success) { "Green" } else { "Yellow" })
        Write-Host "       $snippet"
    } catch {
        $code = $_.Exception.Response.StatusCode.value__
        Write-Host "[FAIL] $label [HTTP $code]" -ForegroundColor Red
        Write-Host "       $($_.ErrorDetails.Message)"
    }
}

Write-Host "`n=== INTRANET ===" -ForegroundColor Cyan
Hit "[1]  GET  intranet/conversations"           "GET"  "$B/api/v1/intranet/conversations"
Hit "[2]  POST intranet/conversations/1/messages" "POST" "$B/api/v1/intranet/conversations/1/messages" '{"body":"Smoke test message from API"}'
Hit "[3]  GET  intranet/conversations/1/messages" "GET"  "$B/api/v1/intranet/conversations/1/messages"
Hit "[4]  POST intranet/conversations/1/read"    "POST" "$B/api/v1/intranet/conversations/1/read"     '{"last_message_id":1}'
Hit "[5]  POST intranet/broadcast"               "POST" "$B/api/v1/intranet/broadcast"                '{"title":"Staff Notice","body":"All hands meeting 9am"}'

Write-Host "`n=== EXTRANET ===" -ForegroundColor Cyan
Hit "[6]  GET  extranet/conversations"           "GET"  "$B/api/v1/extranet/conversations"
Hit "[7]  POST extranet/conversations (new)"     "POST" "$B/api/v1/extranet/conversations"            '{"title":"Inter-Farm Smoke Test","members":[],"kind":"group"}'
Hit "[8]  GET  extranet/connections"             "GET"  "$B/api/v1/extranet/connections"
Hit "[9]  GET  extranet/farms/search?q=farm"     "GET"  "$B/api/v1/extranet/farms/search?q=farm"
Hit "[10] POST messages/1/report"                "POST" "$B/api/v1/messages/1/report"                 '{"reason":"test report"}'

Write-Host "`n=== DONE ===" -ForegroundColor Cyan
