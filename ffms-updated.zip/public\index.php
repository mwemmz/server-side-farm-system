<?php
// Idle session timeout (30 min). Must be set before session_start so that
// session.gc_maxlifetime actually applies (ini_set after session_start warns).
$idleLimit = 1800;
ini_set('session.gc_maxlifetime', (string) $idleLimit);
session_start();
ini_set('display_errors', 0);
ini_set('log_errors', 1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../src/Helpers/CsrfHelper.php';
require_once __DIR__ . '/../src/Helpers/RbacHelper.php';
require_once __DIR__ . '/../src/Helpers/AuditHelper.php';

// Hostile-input guard: only known fields may be arrays (e.g. animal_ids[]); any other
// array value is blanked so controllers never receive an array where text is expected.
foreach (['_POST' => $_POST, '_GET' => $_GET] as $__k => $__v) {
    foreach ($__v as $__name => $__val) {
        if (is_array($__val) && !in_array($__name, ['animal_ids'], true)) {
            if ($__k === '_POST') { $_POST[$__name] = ''; } else { $_GET[$__name] = ''; }
        }
    }
}

// Last-resort handler: bad data (too long, out of range, missing parent record) becomes a
// friendly message on the page the user came from, never a blank 500.
set_exception_handler(function ($e) {
    error_log('FFMS unhandled: ' . get_class($e) . ': ' . $e->getMessage());
    $state = ($e instanceof PDOException) ? substr((string) $e->getCode(), 0, 2) : '';
    $userData = in_array($state, ['22', '23'], true) || $e instanceof TypeError || $e instanceof ValueError;
    $msg = $userData
        ? 'That could not be saved. Check the values (length, numbers, and that linked records exist) and try again.'
        : 'Something went wrong on our side. Please try again.';
    if (!headers_sent() && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        $_SESSION['flash']['error'] = $msg;
        $ref = parse_url($_SERVER['HTTP_REFERER'] ?? '', PHP_URL_QUERY);
        $host = parse_url($_SERVER['HTTP_REFERER'] ?? '', PHP_URL_HOST);
        $sameHost = ($host === null) || ($host === preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? ''));
        $back = ($ref && $sameHost) ? 'index.php?' . $ref : 'index.php?module=Dashboard';
        header('Location: ' . $back);
        exit;
    }
    if (!headers_sent()) { http_response_code($userData ? 422 : 500); }
    echo '<!doctype html><meta charset="utf-8"><title>Error</title><p style="font-family:sans-serif;margin:2rem">' . htmlspecialchars($msg) . ' <a href="index.php?module=Dashboard">Back to dashboard</a></p>';
});

// Run migrations + seeding automatically
require_once __DIR__ . '/../db/migrate.php';

$module = $_GET['module'] ?? 'Dashboard';
$action = $_GET['action'] ?? 'index';

// --- A1: Central CSRF protection for every state-changing request ---
require_once __DIR__ . '/../src/Helpers/SessionHelper.php';
$reqMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$wantsJson = (stripos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false)
    || (strcasecmp($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '', 'XMLHttpRequest') === 0)
    || ($module === 'Lookup')
    || ($module === 'Insights')
    || ($module === 'Labour' && $action === 'emp_add');
$providedToken = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');

// Actions that must never be reachable by a plain GET (no link-prefetch/CSRF-by-image).
$mustPostActions = ['delete', 'approve', 'reject', 'resolve', 'paid',
                    'mark_read', 'mark_all_read', 'run_rules', 'toggle_rule', 'delete_rule',
                    'panel_act', 'incidentStatus', 'recordService'];
if (in_array($action, $mustPostActions, true) && $reqMethod !== 'POST') {
    http_response_code(405);
    if ($wantsJson) {
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['success' => false, 'error' => 'This action must be submitted as a POST request.']);
    } else {
        echo "<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>Action not allowed</title></head>"
           . "<body style='font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0'>"
           . "<div style='max-width:26rem;padding:2rem;text-align:center'>"
           . "<h2 style='margin:0 0 .5rem'>Action not allowed</h2>"
           . "<p style='color:#94a3b8'>For your security this action must be submitted from the application.</p>"
           . "<p style='margin-top:1.5rem'><a href='index.php' style='color:#4ade80;font-weight:600'>Back to dashboard</a></p></div></body></html>";
    }
    exit;
}

if ($reqMethod === 'POST' && !SessionHelper::csrfValidate($providedToken)) {
    http_response_code(403);
    if ($wantsJson) {
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['success' => false, 'error' => 'Invalid or missing security token.']);
    } else {
        echo "<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>Session expired</title></head>"
           . "<body style='font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0'>"
           . "<div style='max-width:26rem;padding:2rem;text-align:center'>"
           . "<h2 style='margin:0 0 .5rem'>Your session expired</h2>"
           . "<p style='color:#94a3b8'>Go back, reload the page and try again.</p>"
           . "<p style='margin-top:1.5rem'><a href='index.php' style='color:#4ade80;font-weight:600'>Back to the app</a></p></div></body></html>";
    }
    exit;
}

// --- Authentication actions (login/logout) handled before the auth gate ---
if ($module === 'Security' && in_array($action, ['login', 'logout'], true)) {
    require_once __DIR__ . '/../src/Modules/Security/SecurityController.php';
    $controller = new SecurityController($pdo);

    if ($action === 'logout') {
        $controller->logout();
    }

    // login: controller returns [] on GET, ['error' => ...] on failed POST,
    // and redirects on successful POST.
    $loginData = $controller->login();
    $loginError = $loginData['error'] ?? null;

    $content = '';
    require __DIR__ . '/views/login.php';
    exit;
}

if ($module === 'Traceability' && $action === 'public') {
    require_once __DIR__ . '/../src/Services/TraceabilityService.php';
    $history = (new TraceabilityService($pdo))->publicHistory(trim((string) ($_GET['token'] ?? '')));
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['success' => $history !== null, 'data' => $history]);
    exit;
}

// --- Auth gate: every other page requires a logged-in user ---
if (!isset($_SESSION['user_id'])) {
    require_once __DIR__ . '/../src/Helpers/RoleHelper.php';
    $back = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET' ? RoleHelper::safeReturn($_SERVER['REQUEST_URI'] ?? '') : null;
    header('Location: index.php?module=Security&action=login' . ($back ? '&return_to=' . urlencode($back) : ''));
    exit;
}

// --- Idle session timeout (30 min): log it and bounce back to login ---
if (isset($_SESSION['last_activity']) && (time() - (int) $_SESSION['last_activity']) > $idleLimit) {
    require_once __DIR__ . '/../src/Modules/Security/SecurityModel.php';
    (new SecurityModel($pdo))->logEvent((int) ($_SESSION['user_id'] ?? 0), 'session_timeout');
    session_unset();
    session_destroy();
    header('Location: index.php?module=Security&action=login&expired=1');
    exit;
}
$_SESSION['last_activity'] = time();

// --- Role home: a bare index.php sends each role to its own landing screen ---
require_once __DIR__ . '/../src/Helpers/RoleHelper.php';
if (!isset($_GET['module']) && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $home = RoleHelper::homeFor($_SESSION['role'] ?? 'worker');
    if ($home !== 'index.php?module=Dashboard') {
        header('Location: ' . $home);
        exit;
    }
}

// --- Role-Based Access Control (RBAC) ---
$role = $_SESSION['role'] ?? 'worker';
$financeOnly = ['admin', 'accountant', 'farm-owner'];
if ($module === 'Finance' && !in_array($role, $financeOnly, true)) {
    die("Access Denied: Only admins can access the Finance module.");
}
if ($module === 'Security' && $action !== 'login' && $role !== 'admin') {
    http_response_code(403);
    exit('Access Denied: Security administration is restricted to admins.');
}
if ($module === 'Analytics') {
    RbacHelper::requirePermission('analytics.read');
}
if ($module === 'Reports') {
    RbacHelper::requirePermission('reports.read');
}

// Authenticated server-side feature actions.
if (in_array($action, ['backup', 'profitability', 'qr_resolve', 'qr_label', 'quick_action', 'assistant_sale_draft', 'assistant_sale_confirm', 'sms_digest', 'trace_create', 'trace_query', 'planner', 'sync_push', 'payment_add', 'receipt', 'translate'], true)) {
    header('Content-Type: application/json; charset=UTF-8');
    $userId = (int) $_SESSION['user_id'];
    if ($action === 'backup') {
        RbacHelper::requirePermission('admin.backup');
        CsrfHelper::requireValid();
        require_once __DIR__ . '/../src/Services/BackupService.php';
        AuditHelper::log($pdo, 'human', 'database_backup', 'database', null, ['format' => 'json'], $userId);
        header('Content-Disposition: attachment; filename="ffms-backup-' . gmdate('Ymd-His') . '.json"');
        echo BackupService::exportJson($pdo);
        exit;
    }
    if ($action === 'profitability') {
        RbacHelper::requirePermission('profit.read');
        require_once __DIR__ . '/../src/Services/FarmMetricsService.php';
        $fieldId = isset($_GET['field_id']) && ctype_digit((string) $_GET['field_id']) ? (int) $_GET['field_id'] : null;
        $animalId = isset($_GET['animal_id']) && ctype_digit((string) $_GET['animal_id']) ? (int) $_GET['animal_id'] : null;
        echo json_encode(['success' => true, 'data' => (new FarmMetricsService($pdo))->profitability($fieldId, $animalId)]);
        exit;
    }
    if ($action === 'qr_resolve' || $action === 'qr_label') {
        RbacHelper::requirePermission('qr.use');
        $tag = trim((string) ($_GET['tag'] ?? ''));
        if ($tag === '' || !preg_match('/^[A-Za-z0-9._:-]{1,80}$/', $tag)) {
            http_response_code(422); echo json_encode(['success' => false, 'error' => 'Invalid tag.']); exit;
        }
        $stmt = $pdo->prepare("SELECT 'animal' AS entity_type, id, type AS name, tag_code FROM livestock WHERE tag_code = ?
            UNION ALL SELECT 'inventory', id, name, tag_code FROM inventory WHERE tag_code = ?
            UNION ALL SELECT 'equipment', id, name, tag_code FROM equipment WHERE tag_code = ?");
        $stmt->execute([$tag, $tag, $tag]);
        $entity = $stmt->fetch() ?: null;
        echo json_encode(['success' => true, 'data' => $entity, 'label' => $entity ? [
            'text' => $entity['entity_type'] . ' #' . $entity['id'] . ' - ' . $entity['name'],
            'qr_value' => $entity['tag_code'],
        ] : null]);
        exit;
    }
    if ($action === 'quick_action') {
        RbacHelper::requirePermission('qr.use');
        CsrfHelper::requireValid();
        $kind = (string) ($_POST['kind'] ?? '');
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        if (!$id || !in_array($kind, ['vaccinate', 'stock_out', 'service'], true)) {
            http_response_code(422); echo json_encode(['success' => false, 'error' => 'Invalid quick action.']); exit;
        }
        $pdo->beginTransaction();
        try {
            if ($kind === 'vaccinate') {
                $name = trim((string) ($_POST['vaccine_name'] ?? ''));
                if ($name === '') throw new InvalidArgumentException('Vaccine name is required.');
                $stmt = $pdo->prepare("INSERT INTO vaccinations (livestock_id, vaccine_name, vaccination_date, next_due_date) VALUES (?, ?, CURRENT_DATE, ?)");
                $stmt->execute([$id, $name, $_POST['next_due_date'] ?? null]);
            } elseif ($kind === 'stock_out') {
                $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);
                if (!$quantity || $quantity < 1) throw new InvalidArgumentException('Quantity must be positive.');
                $stmt = $pdo->prepare("UPDATE inventory SET quantity = quantity - ? WHERE id = ? AND quantity >= ?");
                $stmt->execute([$quantity, $id, $quantity]);
                if ($stmt->rowCount() !== 1) throw new InvalidArgumentException('Insufficient stock or item not found.');
                $pdo->prepare("INSERT INTO stock_movements (item_id, direction, quantity) VALUES (?, 'out', ?)")->execute([$id, $quantity]);
            } else {
                $note = trim((string) ($_POST['notes'] ?? ''));
                if ($note === '') throw new InvalidArgumentException('Service notes are required.');
                $pdo->prepare("UPDATE equipment SET maintenance_status = 'Serviced' WHERE id = ?")->execute([$id]);
            }
            $pdo->commit();
            AuditHelper::log($pdo, 'human', 'qr_quick_action_' . $kind, $kind, $id, $_POST, $userId);
            echo json_encode(['success' => true]); exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            http_response_code(422); echo json_encode(['success' => false, 'error' => $e->getMessage()]); exit;
        }
    }
    if ($action === 'assistant_sale_draft') {
        RbacHelper::requirePermission('assistant.use');
        $text = trim((string) ($_POST['message'] ?? $_GET['message'] ?? ''));
        if (!preg_match('/sold\s+(\d+(?:\.\d+)?)\s+(.+?)\s+(?:k|K)(\d+(?:\.\d+)?)/i', $text, $m)) {
            http_response_code(422); echo json_encode(['success' => false, 'error' => 'Use: sold 3 bags maize K250']); exit;
        }
        echo json_encode(['success' => true, 'draft' => ['quantity' => (float) $m[1], 'item' => trim($m[2]), 'amount' => (float) $m[3], 'sale_date' => date('Y-m-d')]]);
        exit;
    }
    if ($action === 'assistant_sale_confirm') {
        RbacHelper::requirePermission('assistant.use');
        CsrfHelper::requireValid();
        $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
        $customer = trim((string) ($_POST['customer_name'] ?? 'Assistant sale'));
        if ($amount === false || $amount <= 0 || $customer === '') {
            http_response_code(422); echo json_encode(['success' => false, 'error' => 'Valid amount and customer are required.']); exit;
        }
        $stmt = $pdo->prepare("INSERT INTO sales_records (customer_name, amount, sale_date) VALUES (?, ?, ?)");
        $stmt->execute([$customer, $amount, $_POST['sale_date'] ?? date('Y-m-d')]);
        $saleId = (int) $pdo->lastInsertId();
        AuditHelper::log($pdo, 'human', 'assistant_sale_confirmed', 'sale', $saleId, $_POST, $userId);
        echo json_encode(['success' => true, 'sale_id' => $saleId]); exit;
    }
    if ($action === 'sms_digest') {
        RbacHelper::requirePermission('alerts.read');
        CsrfHelper::requireValid();
        require_once __DIR__ . '/../src/Intelligence/InsightsEngine.php';
        require_once __DIR__ . '/../src/Services/NotificationService.php';
        $insightsEngine = new InsightsEngine($pdo);
        $message = 'FFMS daily digest: ' . $insightsEngine->stats()['total'] . ' recommendations need review.';
        $ok = (new NotificationService($pdo))->sendSms((string) ($_POST['recipient'] ?? 'simulator'), $message);
        AuditHelper::log($pdo, 'human', 'sms_digest_simulated', 'notification', null, ['recipient' => $_POST['recipient'] ?? 'simulator'], $userId);
        echo json_encode(['success' => $ok, 'message' => $message]); exit;
    }
    if ($action === 'trace_create') {
        RbacHelper::requirePermission('farm.read');
        require_once __DIR__ . '/../src/Services/TraceabilityService.php';
        try {
            $batch = (new TraceabilityService($pdo))->createBatch($_POST, $userId);
            echo json_encode(['success' => true, 'batch' => $batch]);
        } catch (Throwable $e) {
            http_response_code(422); echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }
    if ($action === 'trace_query') {
        RbacHelper::requirePermission('farm.read');
        require_once __DIR__ . '/../src/Services/TraceabilityService.php';
        $history = (new TraceabilityService($pdo))->publicHistory(trim((string) ($_GET['token'] ?? '')));
        echo json_encode(['success' => $history !== null, 'data' => $history]); exit;
    }
    if ($action === 'planner') {
        RbacHelper::requirePermission('crop.read');
        require_once __DIR__ . '/../src/Services/PlantingPlannerService.php';
        try {
            echo json_encode(['success' => true, 'data' => (new PlantingPlannerService($pdo))->plan($_GET + $_POST)]);
        } catch (Throwable $e) {
            http_response_code(422); echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }
    if ($action === 'sync_push') {
        RbacHelper::requirePermission('sales.write');
        require_once __DIR__ . '/../src/Services/SyncService.php';
        try {
            $payload = json_decode((string) ($_POST['payload'] ?? '{}'), true);
            if (!is_array($payload)) throw new InvalidArgumentException('Payload must be an object.');
            echo json_encode((new SyncService($pdo))->push(trim((string) ($_POST['idempotency_key'] ?? '')), trim((string) ($_POST['operation_type'] ?? '')), $payload, $userId));
        } catch (Throwable $e) {
            http_response_code(422); echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }
    if ($action === 'payment_add') {
        RbacHelper::requirePermission('sales.write');
        require_once __DIR__ . '/../src/Services/PaymentService.php';
        try {
            $id = (new PaymentService($pdo))->record($_POST, $userId);
            echo json_encode(['success' => true, 'payment_id' => $id]);
        } catch (Throwable $e) {
            http_response_code(422); echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }
    if ($action === 'receipt') {
        RbacHelper::requirePermission('sales.read');
        $saleId = filter_var($_GET['sale_id'] ?? null, FILTER_VALIDATE_INT);
        if (!$saleId) { http_response_code(422); echo json_encode(['success' => false, 'error' => 'A valid sale_id is required.']); exit; }
        $stmt = $pdo->prepare("SELECT s.id, s.customer_name, s.amount, s.sale_date, COALESCE(SUM(p.amount),0) AS paid
            FROM sales_records s LEFT JOIN payment_records p ON p.sale_id=s.id AND p.status='paid' WHERE s.id=? GROUP BY s.id");
        $stmt->execute([$saleId]);
        $receipt = $stmt->fetch();
        if (!$receipt) { http_response_code(404); echo json_encode(['success' => false, 'error' => 'Sale not found.']); exit; }
        $receipt['balance'] = max(0, (float) $receipt['amount'] - (float) $receipt['paid']);
        echo json_encode(['success' => true, 'receipt' => $receipt]); exit;
    }
    if ($action === 'translate') {
        RbacHelper::requirePermission('farm.read');
        $language = trim((string) ($_GET['language'] ?? ''));
        $phrase = trim((string) ($_GET['phrase'] ?? ''));
        if (!preg_match('/^[a-z]{2,10}$/', $language) || $phrase === '' || strlen($phrase) > 160) {
            http_response_code(422); echo json_encode(['success' => false, 'error' => 'Invalid translation request.']); exit;
        }
        $stmt = $pdo->prepare("SELECT translation FROM translation_dictionary WHERE language=? AND phrase=?");
        $stmt->execute([$language, $phrase]);
        echo json_encode(['success' => true, 'translation' => $stmt->fetchColumn() ?: $phrase]); exit;
    }
}

$module = $_GET['module'] ?? 'Dashboard';
$action = $_GET['action'] ?? 'index';

// --- Pest is no longer a standalone module: it now lives inside Crop & Livestock.
// Keep the old URL working by redirecting it into the Crop module.
if ($module === 'Pest') {
    header('Location: index.php?module=Crop&action=manage');
    exit;
}

// --- Lookup reference data (dependent combobox options) ---
if ($module === 'Lookup' && $action === 'options') {
    header('Content-Type: application/json; charset=UTF-8');
    require_once __DIR__ . '/../src/Helpers/LookupHelper.php';
    $category = $_GET['category'] ?? '';
    $parent   = $_GET['parent'] ?? '';
    if ($category === 'vaccine_name') {
        $options = [];
        foreach (LookupHelper::vaccineOptions($pdo, $parent !== '' ? $parent : null) as $value => $label) {
            $options[] = ['value' => $value, 'label' => $label];
        }
        echo json_encode(['success' => true, 'options' => $options]);
        exit;
    }
    // Finance categories depend on the chosen type (Income vs Expense).
    if ($category === 'finance_category' && $parent !== '') {
        $listCat = (strtolower($parent) === 'income') ? 'finance_category_income' : 'finance_category_expense';
        echo json_encode(['success' => true, 'options' => LookupHelper::listOptions($pdo, $listCat)]);
        exit;
    }
    $filter   = ($parent !== '') ? ['parent' => $parent] : [];
    echo json_encode(['success' => true, 'options' => LookupHelper::listOptions($pdo, $category, $filter)]);
    exit;
}

// --- Remember a custom value typed into an open combobox (Phase 2) ---
if ($module === 'Lookup' && $action === 'remember') {
    header('Content-Type: application/json; charset=UTF-8');
    require_once __DIR__ . '/../src/Helpers/LookupHelper.php';
    require_once __DIR__ . '/../src/Helpers/SessionHelper.php';

    // Only supervisory roles may add new dropdown values, and the request must
    // carry the session CSRF token (defence against cross-site posting).
    $rememberRoles = ['admin', 'manager', 'accountant'];
    if (!in_array($role, $rememberRoles, true)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'You are not permitted to add list values.']);
        exit;
    }
    if (!SessionHelper::csrfValidate($_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Invalid or missing security token.']);
        exit;
    }

    $category = (string) ($_POST['category'] ?? '');
    $value    = (string) ($_POST['value'] ?? '');
    if (!preg_match('/^[a-z_]{1,40}$/', $category)) {
        echo json_encode(['success' => false, 'error' => 'Invalid category.']);
        exit;
    }
    $canonical = LookupHelper::remember($pdo, $category, $value);
    echo json_encode(['success' => true, 'value' => $canonical]);
    exit;
}

// --- Lookup demo/acceptance page (Phase 1): proves pick-or-type + custom values ---
if ($module === 'Lookup' && $action === 'test') {
    require_once __DIR__ . '/../src/Helpers/LookupHelper.php';
    require_once __DIR__ . '/../src/Helpers/FormHelper.php';
    require_once __DIR__ . '/../src/Helpers/ValidationHelper.php';
    $result = null; $errors = [];
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $breed = trim($_POST['breed'] ?? '');
        $farm  = $_POST['farm_id'] ?? '';
        if ($breed !== '') $breed = LookupHelper::remember($pdo, 'livestock_breed', $breed);
        if (!ValidationHelper::existsIn($pdo, 'farms', $farm)) {
            $errors['farm_id'] = 'Pick an existing farm from the list.';
        }
        if (empty($errors)) $result = ['breed' => $breed, 'farm_id' => (int) $farm];
    }
    $data = ['result' => $result, 'errors' => $errors, 'data' => $_POST];
    ob_start(); require __DIR__ . '/views/lookup_test.php'; $content = ob_get_clean();
    require __DIR__ . '/views/layout.php'; exit;
}

// --- AI/BI (Insights + Assistant): JSON actions + the Insights feed page ---
require_once __DIR__ . '/../src/Intelligence/InsightsEngine.php';
require_once __DIR__ . '/../src/Intelligence/Assistant.php';
require_once __DIR__ . '/../src/Intelligence/MarketAnalysis.php';
$insightsEngine = new InsightsEngine($pdo);
$marketAnalysis = new MarketAnalysis($pdo);

if ($module === 'Insights') {
    if ($action === 'recommendations_json') {
        header('Content-Type: application/json; charset=UTF-8');
        $filter = $_GET['module_filter'] ?? null;
        $json = ['success' => true, 'data' => [
            'recommendations' => $insightsEngine->all($filter),
            'stats'           => $insightsEngine->stats(),
        ]];
        echo json_encode($json);
        exit;
    }
    if ($action === 'chat') {
        header('Content-Type: application/json; charset=UTF-8');
        require_once __DIR__ . '/../src/Intelligence/ChatMemory.php';
        $memory   = new ChatMemory($pdo);
        $userId   = (int) ($_SESSION['user_id'] ?? 0);
        $assistant = new Assistant($pdo);
        $question = $_POST['message'] ?? ($_GET['message'] ?? '');
        $sessionId = (int) ($_POST['session_id'] ?? $_GET['session_id'] ?? 0);
        if (trim($question) === '') {
            // Still create a session so the front-end has an anchor.
            if ($sessionId <= 0) $sessionId = $memory->createSession($userId);
            echo json_encode(['success' => true, 'data' => [
                'type' => 'error',
                'text' => 'Ask me something about your farm…',
                'cards' => [],
            ], 'session_id' => $sessionId]);
            exit;
        }
        if ($sessionId <= 0) {
            $sessionId = $memory->createSession($userId, $memory->makeTitle($question));
        } else {
            $own = $memory->history($sessionId, $userId);
            if (!$own) $sessionId = $memory->createSession($userId, $memory->makeTitle($question));
        }
        $memory->append($sessionId, $userId, 'user', $question);
        $reply = $assistant->answer($question);
        $memory->append($sessionId, $userId, 'assistant', $reply['text'], $reply['cards'] ?? []);
        echo json_encode(['success' => true, 'data' => $reply, 'session_id' => $sessionId]);
        exit;
    }

    if ($action === 'chat_sessions') {
        header('Content-Type: application/json; charset=UTF-8');
        require_once __DIR__ . '/../src/Intelligence/ChatMemory.php';
        $memory = new ChatMemory($pdo);
        echo json_encode(['success' => true, 'data' => [
            'sessions' => $memory->sessions((int) ($_SESSION['user_id'] ?? 0)),
            'active'   => (int) ($_GET['session_id'] ?? 0),
        ]]);
        exit;
    }

    if ($action === 'chat_history') {
        header('Content-Type: application/json; charset=UTF-8');
        require_once __DIR__ . '/../src/Intelligence/ChatMemory.php';
        $memory = new ChatMemory($pdo);
        $hist = $memory->history((int) ($_GET['session_id'] ?? 0), (int) ($_SESSION['user_id'] ?? 0));
        if (!$hist) {
            echo json_encode(['success' => false, 'error' => 'Session not found']);
            exit;
        }
        echo json_encode(['success' => true, 'data' => $hist]);
        exit;
    }

    // Market Analysis & Price Prediction (Predictive Analytics expansion).
    if ($action === 'market_json') {
        header('Content-Type: application/json; charset=UTF-8');
        $crop  = $_GET['crop'] ?? 'Tomato';
        $plant = max(1, min(12, (int) ($_GET['plant_month'] ?? 2)));
        echo json_encode([
            'success' => true,
            'data' => [
                'crops'      => $marketAnalysis->crops(),
                'crop'       => ucfirst((string) $crop),
                'plant_month'=> $plant,
                'history'    => $marketAnalysis->priceHistory($crop, 2),
                'report'     => $marketAnalysis->decisionReport($crop, $plant),
            ],
        ]);
        exit;
    }

    // Market Analysis landing page (interactive "what to plant" tool).
    if (($_GET['view'] ?? '') === 'market') {
        $viewFile = __DIR__ . "/views/market_analysis.php";
        if (file_exists($viewFile)) {
            $data = [];
            ob_start();
            require $viewFile;
            $content = ob_get_clean();
            require __DIR__ . "/views/layout.php";
            exit;
        }

        if (($_GET['view'] ?? '') === 'planner') {
            $viewFile = __DIR__ . "/views/planner.php";
            $content = file_exists($viewFile) ? file_get_contents($viewFile) : '';
            require __DIR__ . "/views/layout.php";
            exit;
        }
    }

    // Feed page.
    $viewFile = __DIR__ . "/views/insights_landing.php";
    if (file_exists($viewFile)) {
        $engine = $insightsEngine;
        $recs   = $engine->all();
        $stats  = $engine->stats();
        ob_start();
        require $viewFile;
        $content = ob_get_clean();
        require __DIR__ . "/views/layout.php";
        exit;
    }
}

// --- Phase 8: Labour Management -> full HR module (admin/manager only) ---
if ($module === 'Labour') {
    $labourAdminRoles = ['admin', 'manager'];
    if (!in_array($role, $labourAdminRoles, true)) {
        die("Access Denied: Labour/HR management is restricted to admin and manager roles.");
    }
    require_once __DIR__ . '/../src/Modules/Labour/LabourController.php';
    $labour = new LabourController($pdo);
    $sub = $_GET['subsection'] ?? null;

    // Live JSON: employee list (for the live-add table refresh) and live employee add.
    if ($action === 'emp_json') {
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['success' => true, 'data' => $labour->hrNew()->employees(isset($_GET['dept']) ? (int) $_GET['dept'] : null)]);
        exit;
    }
    if ($action === 'emp_add') {
        header('Content-Type: application/json; charset=UTF-8');
        $name = trim($_POST['name'] ?? '');
        if ($name === '') { echo json_encode(['success' => false, 'error' => 'Name is required.']); exit; }
        $id = $labour->hrNew()->addEmployee($_POST);
        echo json_encode($id ? ['success' => true, 'id' => $id] : ['success' => false, 'error' => 'Failed to add employee.']);
        exit;
    }

    // POST add for any sub-section -> redirect back to its view.
    if ($action === 'add' && $sub) {
        $res = $labour->handleAdd($sub);
        SessionHelper::setFlash($res === true ? 'success' : 'error', $res === true ? "Saved successfully." : (is_string($res) ? $res : "Failed."));
        header('Location: index.php?module=Labour&subsection=' . urlencode($sub));
        exit;
    }

    // Sub-actions (approve/reject leave, resolve grievance, mark payroll paid).
    if (in_array($action, ['approve', 'reject', 'resolve', 'paid'], true) && $sub) {
        $labour->handleAction($sub, $action);
        header('Location: index.php?module=Labour&subsection=' . urlencode($sub));
        exit;
    }

    // Sub-section view.
    if ($sub) {
        $subFile = __DIR__ . "/views/labour_{$sub}.php";
        if (file_exists($subFile)) {
            if (method_exists($labour, $sub . 'View')) {
                $data = $labour->{$sub . 'View'}();
            } else {
                $data = [];
            }
            ob_start();
            require $subFile;
            $content = ob_get_clean();
            require __DIR__ . "/views/layout.php";
            exit;
        }
    }

    // HR dashboard landing.
    $viewFile = __DIR__ . "/views/labour_landing.php";
    if (file_exists($viewFile)) {
        $data = $labour->dashboardView();
        $data['upcoming_leave'] = $labour->hrNew()->upcomingLeave(30);
        $data['pending_leave_list'] = $labour->hrNew()->leaveRequests(true);
        $data['recent_training'] = array_slice($labour->hrNew()->training(), 0, 5);
        ob_start();
        require $viewFile;
        $content = ob_get_clean();
        require __DIR__ . "/views/layout.php";
        exit;
    }
}

// --- Ops: metadata-driven operational records (fields, crops, livestock,
// equipment, labour, harvest, market, suppliers) ---------------------------
if ($module === 'Ops') {
    require_once __DIR__ . '/../src/Modules/Ops/OpsController.php';
    $ops = new OpsController($pdo);
    $opsView = trim((string) ($_GET['view'] ?? ''));
    if (in_array($action, ['add', 'edit', 'delete'], true)) {
        $data = $ops->$action();
        $opsFile = 'ops_records.php';
    } elseif ($opsView !== '') {
        $data = $ops->records();
        $opsFile = 'ops_records.php';
    } else {
        $data = $ops->landing();
        $opsFile = 'ops_landing.php';
    }
    ob_start();
    require __DIR__ . '/views/' . $opsFile;
    $content = ob_get_clean();
    require __DIR__ . '/views/layout.php';
    exit;
}

// --- Finance: loans & budgets (sub-views demoted behind panel buttons) ---
if ($module === 'Finance' && in_array($action, ['loans', 'budgets'], true)) {
    require_once __DIR__ . '/../src/Modules/Finance/FinanceController.php';
    $finance = new FinanceController($pdo);
    $finView = ($action === 'loans') ? 'finance_loans.php' : 'finance_budgets.php';
    $data = $finance->$action();
    ob_start();
    require __DIR__ . '/views/' . $finView;
    $content = ob_get_clean();
    require __DIR__ . '/views/layout.php';
    exit;
}

// --- Notifications: mark-as-read + alert-rule actions and rules view ---
if ($module === 'Notifications') {
    require_once __DIR__ . '/../src/Modules/Notifications/NotificationsController.php';
    $notif = new NotificationsController($pdo);
    $notifMap = [
        'mark_read'     => 'markRead',
        'mark_all_read' => 'markAllRead',
        'run_rules'     => 'runRules',
        'toggle_rule'   => 'toggleRule',
        'delete_rule'   => 'deleteRule',
    ];
    if (isset($notifMap[$action])) {
        $method = $notifMap[$action];
        if (in_array($action, ['mark_read', 'toggle_rule', 'delete_rule'], true)) {
            $notif->$method((int) ($_GET['id'] ?? 0));
        } else {
            $notif->$method();
        }
        header('Location: index.php?module=Notifications&action=manage');
        exit;
    }
    if ($action === 'rules') {
        $data = $notif->rules();
        ob_start();
        require __DIR__ . '/views/notifications_rules.php';
        $content = ob_get_clean();
        require __DIR__ . '/views/layout.php';
        exit;
    }
}

// --- Security: password change, user management, audit log ---
if ($module === 'Security') {
    require_once __DIR__ . '/../src/Modules/Security/SecurityController.php';
    $secCtrl = new SecurityController($pdo);
    if ($action === 'change_password') {
        $data = $secCtrl->changePassword();
        ob_start(); require __DIR__ . '/views/security_password.php'; $content = ob_get_clean();
        require __DIR__ . '/views/layout.php'; exit;
    }

    if ($module === 'Traceability') {
        if ($action === 'create' && $reqMethod === 'POST') {
            require_once __DIR__ . '/../src/Services/TraceabilityService.php';
            try {
                (new TraceabilityService($pdo))->createBatch($_POST, (int) $_SESSION['user_id']);
                SessionHelper::setFlash('success', 'Harvest batch created.');
            } catch (Throwable $e) {
                SessionHelper::setFlash('error', $e->getMessage());
            }
            header('Location: index.php?module=Traceability');
            exit;
        }
        $data = ['flash' => SessionHelper::getFlash('success'), 'error' => SessionHelper::getFlash('error')];
        ob_start(); require __DIR__ . '/views/traceability.php'; $content = ob_get_clean();
        require __DIR__ . '/views/layout.php'; exit;
    }
    if ($action === 'users') {
        if ($role !== 'admin') { die("Access Denied: User management is restricted to admins."); }
        $data = $secCtrl->users();
        ob_start(); require __DIR__ . '/views/security_users.php'; $content = ob_get_clean();
        require __DIR__ . '/views/layout.php'; exit;
    }
    if ($action === 'audit') {
        $data = $secCtrl->auditLog();
        ob_start(); require __DIR__ . '/views/security_audit.php'; $content = ob_get_clean();
        require __DIR__ . '/views/layout.php'; exit;
    }
    $data = $secCtrl->index();
    ob_start(); require __DIR__ . '/views/security.php'; $content = ob_get_clean();
    require __DIR__ . '/views/layout.php'; exit;
}

if ($module === 'Dashboard') {
    $viewFile = __DIR__ . "/views/dashboard.php";
    ob_start();
    require $viewFile;
    $content = ob_get_clean();
    require __DIR__ . "/views/layout.php";
    exit;
}

$controllerFile = __DIR__ . "/../src/Modules/{$module}/{$module}Controller.php";
$viewFile = __DIR__ . "/views/" . strtolower($module) . ".php";

// --- Phase 6: Control-panel modules (live dashboards) ---
$panelModules = ['Irrigation', 'Storage', 'Equipment', 'Livestock', 'Weather', 'Finance'];
if (in_array($module, $panelModules, true)) {
    // Live polling JSON endpoint (session-authenticated).
    if ($action === 'panel_json' || $action === 'panel_act') {
        require_once __DIR__ . '/../src/Intelligence/Panels/PanelJsonGateway.php';
        PanelJsonGateway::dispatch($pdo, $module, $_GET);
        exit;
    }

    // Module landing (tap) -> panel view, unless an explicit CRUD action is requested.
    $isCrudAction = in_array($action, ['add', 'edit', 'delete', 'manage', 'profile', 'nextTag'], true)
        || ($_SERVER['REQUEST_METHOD'] === 'POST');
    $panelView = __DIR__ . "/views/" . strtolower($module) . "_panel.php";

    if (!$isCrudAction && file_exists($panelView)) {
        require_once $controllerFile;
        $controllerName = "{$module}Controller";
        $controller = new $controllerName($pdo);
        $data = $controller->index();

        ob_start();
        require $panelView;
        $content = ob_get_clean();
        require __DIR__ . "/views/layout.php";
        exit;
    }
}

// --- Phase 6b: landings for form-first modules (CRUD demoted behind a button).
// A general 'manage' action renders each module's original CRUD view (form + list).
if ($action === 'manage' && file_exists($controllerFile) && file_exists($viewFile)) {
    require_once $controllerFile;
    $controllerName = "{$module}Controller";
    $controller = new $controllerName($pdo);
    $data = method_exists($controller, 'index') ? $controller->index() : [];
    ob_start();
    require $viewFile;
    $content = ob_get_clean();
    require __DIR__ . "/views/layout.php";
    exit;
}

// Module tap ('index' on GET) lands on a relevant view: a bespoke
// {module}_landing.php when one exists (e.g. Farm/Field Leaflet maps),
// otherwise the shared generic landing. Panel modules already exited above.
if ($action === 'index' && $_SERVER['REQUEST_METHOD'] !== 'POST' && !in_array($module, $panelModules, true)) {
    $bespoke = __DIR__ . "/views/" . strtolower($module) . "_landing.php";
    $landing = file_exists($bespoke) ? $bespoke : __DIR__ . "/views/partials/generic_landing.php";
    if (file_exists($controllerFile)) {
        require_once $controllerFile;
        $controllerName = "{$module}Controller";
        $controller = new $controllerName($pdo);
        $data = method_exists($controller, 'index') ? $controller->index() : [];
        ob_start();
        require $landing;
        $content = ob_get_clean();
        require __DIR__ . "/views/layout.php";
        exit;
    }
}

if (file_exists($controllerFile) && file_exists($viewFile)) {
    require_once $controllerFile;
    $controllerName = "{$module}Controller";
    $controller = new $controllerName($pdo);

    if (method_exists($controller, $action)) {
        $data = $controller->$action();

        // Capture view content
        ob_start();
        require $viewFile;
        $content = ob_get_clean();

        // Include layout
        require __DIR__ . "/views/layout.php";
    } else {
        http_response_code(404);
        echo "Action not found.";
    }
} else {
    http_response_code(404);
    echo "Module/View not found.";
}
?>