# FFMS — Intelligent Farm Management System

A PHP 8 + PostgreSQL web application for running an entire agribusiness: crops,
livestock, inventory, procurement, sales, finance, labour, storage, equipment,
weather and more — with a "smart" layer (searchable pick-or-type dropdowns,
automatic schedules, cross-module auto-posting and "needs attention" alerts).

## Stack

- PHP 8.2 (Apache), PostgreSQL
- Vanilla PHP views + Tailwind (CDN) + a small combobox/panel JS layer
- Deployed on Render via Docker (`Dockerfile`); config comes from environment variables
- Optional metadata-driven "Ops" record engine exposing ~35 operational tables
  (soil, planting, fertilizer, sprays, chemical applications, treatment follow-ups,
  animal weights, breeding, production, mortality, feed, equipment allocations,
  fuel, hours, repairs, depreciation, daily tasks, harvest schedules/losses,
  packaging, quality, dispatches, customers, markets, orders, invoices, contracts,
  supplier quotations/reviews, field history, land-use plans, seed records) via
  `module=Ops` and `module=Ops&view=<key>`.

## Configuration

Configuration is read by `getEnvVar()` in `config/env.php`, which checks **real
environment variables first** and only then falls back to a local `.env` file.
On Render, set these under **Environment** — do not commit a `.env` file.

| Variable | Purpose | Example |
| --- | --- | --- |
| `DB_HOST` | PostgreSQL host | `localhost` |
| `DB_PORT` | PostgreSQL port | `5432` |
| `DB_NAME` | Database name | `farm_system` |
| `DB_USER` | Database user | `postgres` |
| `DB_PASS` | Database password | *(secret)* |
| `DEFAULT_LAT` | Default map latitude | `-15.3875` |
| `DEFAULT_LON` | Default map longitude | `28.3228` |
| `SMTP_HOST` | SMTP server | `smtp.example.com` |
| `SMTP_PORT` | SMTP port | `587` |
| `SMTP_USER` | SMTP username | `user@example.com` |
| `SMTP_PASS` | SMTP password | *(secret)* |
| `SMTP_FROM` | From address | `user@example.com` |
| `SMTP_FROM_NAME` | From display name | `FFMS` |
| `JWT_SECRET` | HS256 signing key for `/api/v1` | *(long random secret)* |
| `CRON_SECRET` | Gate for the cron runner | *(long random secret)* |

Copy `.env.example` to `.env` for local development. `.env` is git-ignored and
must **never** be committed. See `docs/SMART_FORMS_AUDIT.md` for the smart-forms
rollout status.

> **Security:** if real credentials were ever committed, they remain in git
> history — rotate the database password and SMTP password, and set fresh
> `JWT_SECRET` / `CRON_SECRET` values.

## Local development

```bash
composer install
php -S localhost:8000 -t public        # or point Apache at public/
```

Migrations and seed data run automatically on boot (`db/migrate.php`).

## Automated regression

```bash
DB_HOST=localhost DB_PORT=5432 DB_NAME=farm_system DB_USER=postgres DB_PASS=postgres \
php -S localhost:8000 -t public &   # local server ONLY — never point BASE at the hosted DB
BASE=http://localhost:8000 bash tests/regression.sh
```

The suite logs in, then asserts CSRF/validation guards, stock-movement maths
(in/out, below-zero refusal, parallel races), reorder + procurement behaviour,
dropdown rendering, storage units + harvest-to-storage, vaccine/species rules,
equipment service reminders, Ops metadata-engine validation (required fields,
numbers, dates, FKs, cross-field ordering, invoice overpayment, POST-only
deletes, unknown views, RBAC denial), analytics landing + range filter, report
exports (CSV/printable) for the new datasets, a full page sweep for HTTP 200
with no PHP warning output, and an optional PHP log scan (set `PHP_LOG=/path/to/server.log`).

## Manual test — animal tags and roles
1. Add an animal with the Tag box empty: it gets `COW-00N` (species prefix + next number on that farm). Add one with your own ear tag (e.g. `KE-4471`); adding the same tag again on the same farm is refused.
2. Open the Animal Register, filter by species/status, click a tag to open the animal profile, press Edit and mark one animal Sold/Dead — it disappears from the vaccination, batch, treatment and problem pickers but keeps its history.
3. Record a vaccination by typing part of a tag, breed or name in the Animal box.
4. Log in as each role: admin and manager land on the Dashboard (manager sees no finance totals), accountant lands on Finance, worker lands on "My day" (attention card + quick actions, no money or HR).

## Manual test (6 flows)

1. **Stock in/out & reorder.** Inventory → add an item with a `min_level`;
   record in/out moves and confirm the Quantity badge, the "Balance after"
   column and the Low-stock badge all agree. Try an `out` above the balance —
   it must refuse with "Not enough stock". Create a reorder rule under the
   item's threshold and run the reorder check.
2. **Report a problem (no "Array").** Crop → Pests & Problems → pick an issue
   and a Type; the dropdowns must show real labels (no `>Array<`). Livestock →
   report a pest on an animal the same way; the saved record keeps the plain
   issue name. Mark one treated and optionally deduct a stock item.
3. **Harvest into storage.** Storage → add a facility (unit required, default
   kg — it can be edited). Harvest → "Store in" that facility: stock rises by
   the kg, and harvesting more than the capacity (or a deleted facility id)
   is refused without breaking the harvest record.
4. **Production at a glance.** Crop → record the planted field, area in
   hectares and expected yield per hectare. The Dashboard groups planted
   hectares by produce, estimates the harvest, and shows active livestock
   totals including the cow/cattle count.
5. **Vaccination species rules.** Record a vaccination of Newcastle (NCD) on a
   cow — refused with "is for Poultry, not this Cattle". Goat + PPR vaccine is
   accepted. Batch-vaccinate a cow and a goat together — refused as
   mixed-species. Vaccinate poultry with Marek's: no Next Due date appears
   (single dose at day-old).
6. **Equipment service clock.** Add a Tractor with a purchase date ~10 months
   ago and no interval — it picks up 90 days and shows "Service overdue".
   Record a service: the badge clears to "Service OK" and the next date is set
   purchase-free. Spare-part stock and cost are optional.
7. **CSRF + no 500s.** POST any form without the token → 403. Browse every
   module landing and manage page → all 200, none show PHP warnings; the server
   PHP log stays empty.

## Future work

**Offline-first sync (not implemented — deliberate scope discipline).** A future version could support offline operation on mobile devices using idempotency keys on every mutation, a client-side queue of pending operations, and a conflict strategy of "last-write-wins per record with field-level merge for notes/quantities" reconciled against `updated_at` timestamps on the server. This paragraph documents the intended design; no code is shipped.

`BASE=http://127.0.0.1:8111 python3 tests/smoke_fuzz.py` crawls every page, submits every form with valid and hostile values (decimals, negatives, huge numbers, text in number fields, bad ids, 5000-character strings, array values) and hits every API route. It exits non-zero on any 5xx or PHP error text. Local servers only; it refuses to run against onrender.com.
