$ProgressPreference = 'SilentlyContinue'
$ErrorActionPreference = "Continue"
$B = "https://server-side-farm-system.vercel.app"
$COOKIE_ADMIN  = "$env:TEMP\ffms_admin.txt"
$COOKIE_MGR    = "$env:TEMP\ffms_mgr.txt"
$COOKIE_WKR    = "$env:TEMP\ffms_wkr.txt"
$results = [System.Collections.ArrayList]::new()

function Check($label, $pass, $note="") {
    $icon  = if ($pass) { "[PASS]" } else { "[FAIL]" }
    $color = if ($pass) { "Green"  } else { "Red"    }
    $line  = if ($note) { "$icon $label -- $note" } else { "$icon $label" }
    Write-Host $line -ForegroundColor $color
    $null = $results.Add(@{label=$label;pass=$pass})
}

function CurlGet($url, $cookieFile=$null, $token=$null) {
    $args = @("-s", $url)
    if ($cookieFile) { $args += @("-b", $cookieFile, "-c", $cookieFile) }
    if ($token)      { $args += @("-H", "Authorization: Bearer $token") }
    return & curl.exe @args 2>&1
}

function CurlPost($url, $body, $cookieFile=$null, $token=$null, $json=$false) {
    $ct = if ($json) { "application/json" } else { "application/x-www-form-urlencoded" }
    $args = @("-s", "-w", "`n%{http_code}", "-X", "POST", "-H", "Content-Type: $ct", "--data-raw", $body, $url)
    if ($cookieFile) { $args += @("-b", $cookieFile, "-c", $cookieFile) }
    if ($token)      { $args += @("-H", "Authorization: Bearer $token") }
    return & curl.exe @args 2>&1
}

function GetCsrf($html) {
    if ($html -match 'name="csrf_token"\s+value="([^"]+)"') { return $Matches[1] }
    return ""
}

function GetHttpCode($curlOutput) {
    $lines = $curlOutput -split "`n"
    return ($lines | Select-Object -Last 1).Trim()
}

function GetBody($curlOutput) {
    $lines = $curlOutput -split "`n"
    return ($lines | Select-Object -SkipLast 1) -join "`n"
}

# ─── STEP 1: Admin JWT login ─────────────────────────────────────────────────
Write-Host "`n=== STEP 1: Admin JWT login ===" -ForegroundColor Cyan
$out   = CurlPost "$B/api/v1/auth/token" '{"username":"admin","password":"admin123"}' -json $true
$body  = GetBody $out
$code  = GetHttpCode $out
$admin = $body | ConvertFrom-Json
$adminToken = $admin.data.token
Check "Admin JWT login" ($code -eq "200" -and $adminToken.Length -gt 0) "role=$($admin.data.user.role)"

# ─── STEP 2: Web login as admin ──────────────────────────────────────────────
Write-Host "`n=== STEP 2: Web login + create accounts ===" -ForegroundColor Cyan
$loginPage = CurlGet "$B/?module=Security&action=login" $COOKIE_ADMIN
$csrf = GetCsrf ($loginPage -join "`n")
$loginBody = "username=admin&password=admin123&csrf_token=" + [Uri]::EscapeDataString($csrf)
$out = CurlPost "$B/?module=Security&action=login" $loginBody $COOKIE_ADMIN
Check "Admin web login" ((GetHttpCode $out) -eq "302")

# Create manager
$usersPage = CurlGet "$B/?module=Security&action=users" $COOKIE_ADMIN
$csrf = GetCsrf ($usersPage -join "`n")
$b = "username=farm_manager&email=manager%40test.farm&password=Manager123%21&role=manager&csrf_token=" + [Uri]::EscapeDataString($csrf)
$out = CurlPost "$B/?module=Security&action=users" $b $COOKIE_ADMIN
$body = GetBody $out; $code = GetHttpCode $out
Check "Create farm_manager user" ($code -eq "302" -or $body -match "created|already taken")

# Create worker
$usersPage = CurlGet "$B/?module=Security&action=users" $COOKIE_ADMIN
$csrf = GetCsrf ($usersPage -join "`n")
$b = "username=farm_worker&email=worker%40test.farm&password=Worker123%21&role=worker&csrf_token=" + [Uri]::EscapeDataString($csrf)
$out = CurlPost "$B/?module=Security&action=users" $b $COOKIE_ADMIN
$body = GetBody $out; $code = GetHttpCode $out
Check "Create farm_worker user" ($code -eq "302" -or $body -match "created|already taken")

# ─── STEP 3: JWT logins for new accounts ─────────────────────────────────────
Write-Host "`n=== STEP 3: JWT logins for new accounts ===" -ForegroundColor Cyan
$out = CurlPost "$B/api/v1/auth/token" '{"username":"farm_manager","password":"Manager123!"}' -json $true
$mgr = (GetBody $out | ConvertFrom-Json).data
$mgrToken = $mgr.token
Check "Manager JWT login" ($mgrToken.Length -gt 0) "role=$($mgr.user.role)"

$out = CurlPost "$B/api/v1/auth/token" '{"username":"farm_worker","password":"Worker123!"}' -json $true
$wkr = (GetBody $out | ConvertFrom-Json).data
$wkrToken = $wkr.token
Check "Worker JWT login" ($wkrToken.Length -gt 0) "role=$($wkr.user.role)"

# ─── STEP 4: API RBAC ────────────────────────────────────────────────────────
Write-Host "`n=== STEP 4: API RBAC checks ===" -ForegroundColor Cyan
$r = CurlGet "$B/api/v1/intranet/conversations" -token $mgrToken
Check "Manager: intranet conversations" (($r | ConvertFrom-Json).success -eq $true)

$r = CurlGet "$B/api/v1/extranet/connections" -token $mgrToken
Check "Manager: extranet connections" (($r | ConvertFrom-Json).success -eq $true)

$r = CurlGet "$B/api/v1/extranet/farms/search?q=" -token $mgrToken
Check "Manager: farm search" (($r | ConvertFrom-Json).success -eq $true)

$r = CurlGet "$B/api/v1/intranet/conversations" -token $wkrToken
Check "Worker: intranet conversations (allowed)" (($r | ConvertFrom-Json).success -eq $true)

$r = CurlGet "$B/api/v1/extranet/farms/search?q=" -token $wkrToken
$rj = $r | ConvertFrom-Json
Check "Worker: farm search BLOCKED (no connections.read)" ($rj.success -eq $false -or $rj.error -ne $null) "HTTP — worker has no connections.read perm"

# ─── STEP 5: Create employee records ─────────────────────────────────────────
Write-Host "`n=== STEP 5: Create employee records ===" -ForegroundColor Cyan
$empPage = CurlGet "$B/?module=Labour&subsection=employees" $COOKIE_ADMIN
$csrf = GetCsrf ($empPage -join "`n")
$b = "name=farm_manager&job_title=Farm+Manager&employment_status=active&contract_type=permanent&pay_type=monthly&monthly_salary=5000&hire_date=2024-01-01&csrf_token=" + [Uri]::EscapeDataString($csrf)
$out = CurlPost "$B/?module=Labour&action=add&subsection=employees" $b $COOKIE_ADMIN
Check "Employee record: farm_manager" ((GetHttpCode $out) -eq "302")

$empPage = CurlGet "$B/?module=Labour&subsection=employees" $COOKIE_ADMIN
$csrf = GetCsrf ($empPage -join "`n")
$b = "name=farm_worker&job_title=Farm+Worker&employment_status=active&contract_type=permanent&pay_type=daily&daily_rate=150&hire_date=2024-03-01&csrf_token=" + [Uri]::EscapeDataString($csrf)
$out = CurlPost "$B/?module=Labour&action=add&subsection=employees" $b $COOKIE_ADMIN
Check "Employee record: farm_worker" ((GetHttpCode $out) -eq "302")

# ─── STEP 6: Worker web session + leave page ─────────────────────────────────
Write-Host "`n=== STEP 6: Worker web session + leave page ===" -ForegroundColor Cyan
$wLoginPage = CurlGet "$B/?module=Security&action=login" $COOKIE_WKR
$csrf = GetCsrf ($wLoginPage -join "`n")
$b = "username=farm_worker&password=Worker123%21&csrf_token=" + [Uri]::EscapeDataString($csrf)
$out = CurlPost "$B/?module=Security&action=login" $b $COOKIE_WKR
Check "Worker web login" ((GetHttpCode $out) -eq "302")

# Follow redirect to establish session
CurlGet "$B/?module=Dashboard" $COOKIE_WKR | Out-Null

$wLP = (CurlGet "$B/?module=Labour&subsection=leave" $COOKIE_WKR) -join "`n"
Check "Worker sees 'My Leave Requests' (worker view)" ($wLP -match "My Leave Requests|Request Leave")
Check "Worker does NOT see Approve buttons" ($wLP -notmatch "action=approve")

# Worker submits leave
$csrf = GetCsrf $wLP
$today = (Get-Date).ToString("yyyy-MM-dd")
$endD  = (Get-Date).AddDays(5).ToString("yyyy-MM-dd")
$b = "leave_type=annual&start_date=$today&end_date=$endD&days=5&reason=Family+vacation&csrf_token=" + [Uri]::EscapeDataString($csrf)
$out = CurlPost "$B/?module=Labour&action=add&subsection=leave" $b $COOKIE_WKR
Check "Worker submits leave request" ((GetHttpCode $out) -eq "302")

# ─── STEP 7: Worker tries to approve (RBAC block) ────────────────────────────
Write-Host "`n=== STEP 7: Worker tries to approve leave (should be blocked) ===" -ForegroundColor Cyan
$wLP2 = (CurlGet "$B/?module=Labour&subsection=leave" $COOKIE_WKR) -join "`n"
$csrf = GetCsrf $wLP2
$b = "csrf_token=" + [Uri]::EscapeDataString($csrf)
$blkOut = (CurlPost "$B/?module=Labour&action=approve&subsection=leave&id=1" $b $COOKIE_WKR) -join "`n"
Check "Worker blocked from approving leave" ($blkOut -match "Only managers|Access denied|error|not.*allowed")

# ─── STEP 8: Manager views + approves pending ────────────────────────────────
Write-Host "`n=== STEP 8: Manager views + approves pending leave ===" -ForegroundColor Cyan
$mLoginPage = CurlGet "$B/?module=Security&action=login" $COOKIE_MGR
$csrf = GetCsrf ($mLoginPage -join "`n")
$b = "username=farm_manager&password=Manager123%21&csrf_token=" + [Uri]::EscapeDataString($csrf)
$out = CurlPost "$B/?module=Security&action=login" $b $COOKIE_MGR
Check "Manager web login" ((GetHttpCode $out) -eq "302")

CurlGet "$B/?module=Dashboard" $COOKIE_MGR | Out-Null

$mLP = (CurlGet "$B/?module=Labour&subsection=leave" $COOKIE_MGR) -join "`n"
Check "Manager sees 'Pending Approvals' (HR view)" ($mLP -match "Pending Approvals")
Check "Manager sees Approve buttons" ($mLP -match "action=approve")

$pendingMatch = [regex]::Match($mLP, "action=approve&subsection=leave&id=(\d+)")
$leaveId = $pendingMatch.Groups[1].Value
Check "Pending leave ID found in manager view" ($leaveId.Length -gt 0) "ID #$leaveId"

if ($leaveId.Length -gt 0) {
    $csrf = GetCsrf $mLP
    $b = "csrf_token=" + [Uri]::EscapeDataString($csrf)
    $appOut = (CurlPost "$B/?module=Labour&action=approve&subsection=leave&id=$leaveId" $b $COOKIE_MGR) -join "`n"
    Check "Manager approves leave #$leaveId" ($appOut -match "Leave Management|success|approved")

    $mLP2 = (CurlGet "$B/?module=Labour&subsection=leave" $COOKIE_MGR) -join "`n"
    Check "Leave #$leaveId removed from pending" ($mLP2 -notmatch "action=approve&subsection=leave&id=$leaveId")
}

# ─── STEP 9: Worker sees approved ────────────────────────────────────────────
Write-Host "`n=== STEP 9: Worker sees approved status ===" -ForegroundColor Cyan
$wLP3 = (CurlGet "$B/?module=Labour&subsection=leave" $COOKIE_WKR) -join "`n"
Check "Worker sees approved status on their request" ($wLP3 -match "approved|Approved")

# ─── STEP 10: Sidebar RBAC ───────────────────────────────────────────────────
Write-Host "`n=== STEP 10: Sidebar RBAC visibility ===" -ForegroundColor Cyan
$wDash = (CurlGet "$B/?module=Dashboard" $COOKIE_WKR) -join "`n"
Check "Worker: Finance NOT in sidebar" ($wDash -notmatch 'href[^>]*module=Finance[^A-Za-z]')
Check "Worker: Users link NOT in sidebar" ($wDash -notmatch "action=users")
Check "Worker: Marketplace IS in sidebar" ($wDash -match "module=Marketplace")
Check "Worker: Notifications IS in sidebar" ($wDash -match "module=Notifications")

$mDash = (CurlGet "$B/?module=Dashboard" $COOKIE_MGR) -join "`n"
Check "Manager: Users link NOT in sidebar" ($mDash -notmatch "action=users")
Check "Manager: Labour IS in sidebar" ($mDash -match "module=Labour")
Check "Manager: Communications IS in sidebar" ($mDash -match "module=Communications")

$finTest = (CurlGet "$B/?module=Finance" $COOKIE_WKR) -join "`n"
Check "Worker: Finance blocked (direct URL)" ($finTest -match "Access Denied")

$secTest = (CurlGet "$B/?module=Security&action=users" $COOKIE_WKR) -join "`n"
Check "Worker: Security/Users blocked (direct URL)" ($secTest -match "Access Denied|403")

# ─── Summary ─────────────────────────────────────────────────────────────────
$pass = ($results | Where-Object { $_["pass"] }).Count
$fail = ($results | Where-Object { !$_["pass"] }).Count
Write-Host "`n============================================" -ForegroundColor Cyan
Write-Host "  RESULTS: $pass PASSED / $fail FAILED" -ForegroundColor $(if($fail -eq 0){"Green"}else{"Yellow"})
Write-Host "============================================" -ForegroundColor Cyan
