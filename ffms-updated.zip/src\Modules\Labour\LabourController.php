<?php
require_once __DIR__ . '/LabourModel.php';
require_once __DIR__ . '/../../Helpers/SessionHelper.php';
require_once __DIR__ . '/../../Helpers/ValidationHelper.php';
require_once __DIR__ . '/../../Intelligence/HrService.php';
require_once __DIR__ . '/../Finance/FinanceService.php';

class LabourController {
    private $model;
    private $hr;
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->model = new LabourModel($pdo);
        $this->hr = new HrService($pdo);
    }

    // Legacy: the original labour_records table (kept for backward compatibility).
    public function index() { return $this->model->getAll(); }

    // Public accessor to the HR service (used by the front controller's JSON endpoints).
    public function hrNew() { return $this->hr; }

    // ---- Human-verifiable employee count for the legacy redirect list ----
    public function legacyList() { return $this->model->getAll(); }

    // ---- Sub-section view data ---------------------------------------
    public function employeesView() {
        $deptId = isset($_GET['dept']) ? (int) $_GET['dept'] : null;
        return [
            'employees' => $this->hr->employees($deptId),
            'departments' => $this->hr->departments(),
        ];
    }
    public function departmentsView() {
        return ['departments' => $this->hr->departments()];
    }
    public function trainingView() {
        return ['training' => $this->hr->training(), 'employees' => $this->hr->employees()];
    }
    public function payrollView() {
        $records = $this->hr->payroll();
        // Attach a computed preview for the "new pay run" form default period.
        return [
            'payroll' => $records,
            'totals' => $this->hr->payrollTotals(),
            'employees' => $this->hr->employees(),
        ];
    }
    public function leaveView() {
        $role = $_SESSION['role'] ?? 'worker';
        require_once __DIR__ . '/../../Helpers/RoleHelper.php';
        $isHr = RoleHelper::seesHr($role);

        // Workers only see their own employee record's leave data.
        // Managers/admins see everything.
        $allEmployees = $this->hr->employees();

        // Try to find the employee record linked to the logged-in user by matching
        // username against employee name (best-effort; falls back to full list for HR).
        $myEmployeeId = null;
        if (!$isHr) {
            $username = $_SESSION['username'] ?? '';
            foreach ($allEmployees as $e) {
                if (strtolower(trim($e['name'])) === strtolower(trim($username))) {
                    $myEmployeeId = (int) $e['id'];
                    break;
                }
            }
        }

        return [
            'balances'     => $this->hr->leaveBalances(),
            'requests'     => $this->hr->leaveRequests(),
            'pending'      => $isHr ? $this->hr->leaveRequests(true) : [],
            'upcoming'     => $isHr ? $this->hr->upcomingLeave(30) : [],
            'employees'    => $isHr ? $allEmployees : ($myEmployeeId ? array_filter($allEmployees, fn($e) => (int)$e['id'] === $myEmployeeId) : $allEmployees),
            'isHr'         => $isHr,
            'myEmployeeId' => $myEmployeeId,
        ];
    }
    public function shiftsView() {
        return [
            'shifts' => $this->hr->shifts(),
            'attendance' => $this->hr->attendance(),
            'employees' => $this->hr->employees(),
        ];
    }
    public function grievancesView() {
        return ['grievances' => $this->hr->grievances(), 'employees' => $this->hr->employees()];
    }
    public function dashboardView() {
        return $this->hr->stats();
    }

    // ---- POST handlers per sub-section (return true/error string) ----
    public function handleAdd($sub) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return null;
        $d = $_POST;
        $name = trim($d['name'] ?? '');
        switch ($sub) {
            case 'employees':
                if ($name === '') return 'Employee name is required.';
                return $this->hr->addEmployee($d) ? true : 'Failed to add employee.';
            case 'departments':
                if ($name === '') return 'Department name is required.';
                return $this->hr->addDepartment($name, trim($d['description'] ?? '')) ? true : 'Failed to add department.';
            case 'training':
                if (empty($d['employee_id']) || empty(trim($d['course_name'] ?? ''))) return 'Employee and course name are required.';
                $e = ValidationHelper::dateNotFuture($d, 'completion_date', 'Completion date');
                if ($e) return $e;
                return $this->hr->addTraining($d) ? true : 'Failed to add training record.';
            case 'payroll':
                if (empty($d['employee_id'])) return 'Select an employee.';
                $emp = $this->hr->employee((int) $d['employee_id']);
                if (!$emp) return 'Employee not found.';
                $bonus = (float) ($d['bonus'] ?? 0);
                $advances = (float) ($d['advances'] ?? 0);
                $loans = (float) ($d['loans'] ?? 0);
                $gross = $this->hr->computeGross($emp, $d['work_days'] ?? 0, $d['work_units'] ?? 0, $d['overtime'] ?? 0);
                $finalGross = round($gross + $bonus, 2);
                $ded = $this->hr->statutoryDeductions($finalGross);
                $net = round($finalGross - $ded['napsa'] - $ded['paye'] - $ded['nhima'] - $advances - $loans, 2);
                return $this->hr->savePayroll($d, $finalGross, $ded, $net) ? true : 'Failed to save pay run.';
            case 'leave':
                if (empty($d['employee_id']) || empty($d['start_date']) || empty($d['end_date'])) return 'Employee and dates are required.';
                return $this->hr->requestLeave($d) ? true : 'Failed to submit leave request.';
            case 'shifts':
                if (empty($d['employee_id']) || empty($d['shift_date'])) return 'Employee and shift date are required.';
                return $this->hr->addShift($d) ? true : 'Failed to add shift.';
            case 'attendance':
                if (empty($d['employee_id']) || empty($d['work_date'])) return 'Employee and work date are required.';
                $e = ValidationHelper::dateNotFuture($d, 'work_date', 'Work date');
                if ($e) return $e;
                return $this->hr->addAttendance($d) ? true : 'Failed to record attendance.';
            case 'grievances':
                if (empty($d['employee_id']) || empty(trim($d['description'] ?? ''))) return 'Employee and description are required.';
                return $this->hr->addGrievance($d) ? true : 'Failed to log grievance.';
        }
        return null;
    }

    // ---- JSON-endpoints (used by live adds) --------------------------
    public function employeesJson() {
        $deptId = isset($_GET['dept']) ? (int) $_GET['dept'] : null;
        header('Content-Type: application/json');
        echo json_encode($this->hr->employees($deptId));
        exit;
    }

    // ---- Sub-action handlers (approve/reject resolve, mark paid) -----
    public function handleAction($sub, $action) {
        $officerId = (int) ($_SESSION['user_id'] ?? 0);
        $role      = $_SESSION['role'] ?? 'worker';
        $id = ValidationHelper::id($_GET['id'] ?? '');
        if ($id === null) return null;

        // Leave approve/reject is HR-only — manager and admin only.
        if (in_array($sub . ':' . $action, ['leave:approve', 'leave:reject'], true)) {
            require_once __DIR__ . '/../../Helpers/RoleHelper.php';
            if (!RoleHelper::seesHr($role)) {
                SessionHelper::setFlash('error', 'Only managers and admins can approve or reject leave requests.');
                header('Location: index.php?module=Labour&subsection=leave');
                exit;
            }
        }
        switch ($sub . ':' . $action) {
            case 'leave:approve':
                return $this->hr->approveLeave($id, $officerId);
            case 'leave:reject':
                return $this->hr->rejectLeave($id, $officerId);
            case 'grievances:resolve':
                return $this->hr->resolveGrievance($id, trim($_POST['resolution_notes'] ?? 'Resolved'));
            case 'payroll:paid':
                $payrollId = $id;
                $result = $this->hr->markPaid($payrollId);
                // Cross-module: a paid payroll run posts a Labour expense (idempotent).
                try {
                    $st = $this->pdo->prepare(
                        "SELECT p.net_pay, p.payment_date, e.name AS employee_name, e.farm_id
                         FROM payroll_records p JOIN employees e ON e.id = p.employee_id
                         WHERE p.id = ? LIMIT 1"
                    );
                    $st->execute([$payrollId]);
                    $pay = $st->fetch();
                    if ($pay) {
                        (new FinanceService($this->pdo))->postSafe(
                            'expense', 'Labour & wages', $pay['net_pay'],
                            'Payroll: ' . ($pay['employee_name'] ?: 'employee'),
                            $pay['farm_id'] ?? null, 'Payroll', $payrollId, $pay['payment_date'] ?: date('Y-m-d'), 'paid'
                        );
                    }
                } catch (PDOException $e) {
                    error_log('Payroll finance post failed: ' . $e->getMessage());
                }
                return $result;
        }
        return null;
    }
}
