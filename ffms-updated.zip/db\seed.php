<?php
// Seed script: creates a default admin account and realistic Zambian mock data.
// Idempotent — safe to run on every app boot (Farms table check + ON CONFLICT).
require_once __DIR__ . '/../config/database.php';

// --- Default admin account (runs every boot, resets password to admin123) ---
try {
    $adminHash = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare(
        "INSERT INTO users (username, password_hash, email, role)
         VALUES ('admin', ?, ?, 'admin')
         ON CONFLICT (username) DO UPDATE
            SET password_hash = EXCLUDED.password_hash,
                role = 'admin',
                email = EXCLUDED.email"
    );
    $stmt->execute([$adminHash, 'admin@ffms.local']);
    foreach ([
        ['owner', 'owner@ffms.local', 'farm-owner'],
        ['agronomist', 'agronomist@ffms.local', 'agronomist'],
    ] as [$username, $email, $role]) {
        $userStmt = $pdo->prepare("INSERT INTO users (username, password_hash, email, role) VALUES (?, ?, ?, ?) ON CONFLICT (username) DO UPDATE SET role = EXCLUDED.role, email = EXCLUDED.email");
        $userStmt->execute([$username, password_hash('demo123', PASSWORD_DEFAULT), $email, $role]);
    }

    // Ensure every demo user is a member of at least the first farm (Wave 1B).
    try {
        $pdo->exec("INSERT INTO farm_members (farm_id, user_id, farm_role)
            SELECT 1, id, role FROM users
            ON CONFLICT (farm_id, user_id) DO NOTHING");
        // Also link all farms for admin.
        $pdo->exec("INSERT INTO farm_members (farm_id, user_id, farm_role)
            SELECT f.id, u.id, 'admin'
            FROM farms f CROSS JOIN users u
            WHERE u.role = 'admin'
            ON CONFLICT (farm_id, user_id) DO NOTHING");
    } catch (PDOException $e) {
        error_log('Seed (farm_members) failed: ' . $e->getMessage());
    }
} catch (PDOException $e) {
    error_log("Seed (admin) failed: " . $e->getMessage());
}

// --- Zambian demo farmers (idempotent) so comms/marketplace can be exercised ---
try {
    $farmers = [
        ['chanda_banda', 'chanda@farm.zm', 'farm-owner', 'Banda Family Farm', 'Chongwe', -15.3200, 28.6800],
        ['mwamba_zulu', 'mwamba@farm.zm', 'farm-owner', 'Zulu Homestead Farm', 'Chibombo', -14.6600, 28.0800],
        ['natasha_phiri', 'natasha@farm.zm', 'farm-owner', 'Phiri Greens', 'Kafue', -15.7700, 28.1800],
        ['tembo_mulenga', 'tembo@farm.zm', 'farm-owner', 'Mulenga Poultry', 'Mazabuka', -15.8600, 27.7600],
        ['grace_mwewa', 'grace@farm.zm', 'farm-owner', 'Mwewa Dairy', 'Kabwe', -14.4500, 28.4500],
    ];
    foreach ($farmers as [$username, $email, $role, $farmName, $loc, $lat, $lon]) {
        $hash = password_hash('demo123', PASSWORD_DEFAULT);
        $st = $pdo->prepare("INSERT INTO users (username, password_hash, email, role) VALUES (?,?,?,?) ON CONFLICT (username) DO UPDATE SET role=EXCLUDED.role, email=EXCLUDED.email");
        $st->execute([$username, $hash, $email, $role]);
        $uid = (int)$pdo->query("SELECT id FROM users WHERE username = " . $pdo->quote($username))->fetchColumn();
        $fst = $pdo->prepare("SELECT id FROM farms WHERE name = ?");
        $fst->execute([$farmName]);
        $fid = $fst->fetchColumn();
        if (!$fid) {
            $ist = $pdo->prepare("INSERT INTO farms (name, location, latitude, longitude) VALUES (?,?,?,?) RETURNING id");
            $ist->execute([$farmName, $loc, $lat, $lon]);
            $fid = (int)$ist->fetchColumn();
        }
        $fid = (int)$fid;
        $pdo->prepare("INSERT INTO farm_members (farm_id, user_id, farm_role) VALUES (?,?,?) ON CONFLICT DO NOTHING")->execute([$fid, $uid, $role]);
        $cnt = (int)$pdo->query("SELECT COUNT(*) FROM marketplace_listings WHERE seller_user_id = $uid")->fetchColumn();
        if ($cnt === 0) {
            $items = [
                ['Maize grain', 'Grain', 500, 'kg', 4.50],
                ['Soybeans', 'Grain', 200, 'kg', 8.00],
                ['Tomatoes', 'Vegetables', 80, 'kg', 12.00],
                ['Groundnuts', 'Legumes', 150, 'kg', 15.00],
            ];
            foreach ($items as [$iname, $cat, $qty, $unit, $price]) {
                $pdo->prepare("INSERT INTO marketplace_listings (seller_farm_id, seller_user_id, item_name, category, quantity, unit, price_per_unit) VALUES (?,?,?,?,?,?,?)")
                    ->execute([$fid, $uid, $iname, $cat, $qty, $unit, $price]);
            }
        }
    }
    error_log("FFMS: Zambian demo farmers + marketplace listings seeded.");
} catch (PDOException $e) {
    error_log("Seed (farmers) failed: " . $e->getMessage());
}

// --- Market Analysis: 2 years of historical price history (idempotent) -----
// Runs every boot (BEFORE the mock-data early return) but only inserts once:
// guarded by "is there already a market record older than ~13 months?".
// This adds the 2-year window the Price Prediction module needs even on a DB
// that is already seeded.
try {
    $hasHistory = (int) $pdo->query(
        "SELECT COUNT(*) FROM market_data WHERE market_date < (CURRENT_DATE - INTERVAL '400 days')"
    )->fetchColumn();
    if ($hasHistory === 0) {
        // Per-crop base price (ZMW/kg) + a 12-month seasonal factor.
        // Zambian pattern: prices firm up in the hot/dry-short-supply months and
        // soften at the main harvest gluts.
        $crops = [
            'Tomato'     => [6.00, [1.32, 1.25, 1.15, 0.78, 0.70, 0.72, 0.80, 0.95, 1.10, 1.18, 1.28, 1.34]],
            'Maize'      => [3.50, [1.15, 1.18, 1.20, 1.12, 0.95, 0.82, 0.78, 0.82, 0.88, 0.95, 1.05, 1.10]],
            'Soybeans'   => [7.20, [1.08, 1.10, 1.05, 0.98, 0.92, 0.88, 0.90, 0.95, 1.00, 1.05, 1.10, 1.08]],
            'Groundnuts' => [12.00, [1.10, 1.15, 1.20, 1.05, 0.92, 0.85, 0.88, 0.95, 1.00, 1.05, 1.10, 1.12]],
            'Wheat'      => [4.80, [1.02, 1.03, 1.05, 1.05, 1.04, 1.02, 1.00, 0.97, 0.95, 0.96, 0.98, 1.00]],
            'Cabbage'    => [2.50, [1.30, 1.26, 1.10, 0.85, 0.78, 0.80, 0.90, 1.00, 1.10, 1.18, 1.26, 1.32]],
            'Onion'      => [3.50, [1.18, 1.20, 1.12, 0.98, 0.90, 0.85, 0.88, 0.95, 1.02, 1.10, 1.16, 1.20]],
            'Sunflower'  => [5.50, [1.05, 1.07, 1.10, 1.05, 0.98, 0.92, 0.90, 0.94, 1.00, 1.04, 1.06, 1.08]],
        ];
        $rows = [];
        $start = new DateTime('2024-01-01');
        $now = new DateTime('now');
        $i = 0;
        foreach ($crops as $crop => [$base, $factors]) {
            $cursor = clone $start;
            while ($cursor <= $now) {
                $m = (int) $cursor->format('n');
                $y = (int) $cursor->format('Y');
                // Small upward drift (~4%/yr) + gentle month-to-month noise for realism.
                $drift = 1.0 + 0.04 * ($y - 2024);
                $price = round($base * $factors[$m - 1] * $drift * (1 + (($i % 7) - 3) / 140), 2);
                $rows[] = "('" . $crop . "', " . $price . ", '" . $cursor->format('Y-m-15') . "')";
                $i++;
                $cursor->modify('+1 month');
            }
        }
        foreach (array_chunk($rows, 300) as $chunk) {
            $pdo->exec("INSERT INTO market_data (crop_name, price, market_date) VALUES " . implode(', ', $chunk));
        }
        error_log("FFMS: Market Analysis historical prices seeded (" . count($rows) . " rows).");
    }
} catch (PDOException $e) {
    error_log("Seed (market prices) failed: " . $e->getMessage());
}

// --- Market Analysis: historical demand (sales) series (idempotent) --------
// Runs every boot before the mock-data early return; guarded idempotently.
try {
    $hasOldSales = (int) $pdo->query(
        "SELECT COUNT(*) FROM sales_records WHERE sale_date < (CURRENT_DATE - INTERVAL '300 days')"
    )->fetchColumn();
    if ($hasOldSales === 0) {
        $rows = [];
        $cursor = new DateTime('2024-01-01');
        $now = new DateTime('now');
        $i = 0;
        // Monthly demand shape: higher buyer activity in May (post-harvest trade)
        // and Nov–Dec (market-goer holidays), dips in Jan–Feb.
        $shape = [0.7, 0.6, 0.8, 0.9, 1.5, 1.3, 1.2, 1.0, 1.1, 1.2, 1.4, 1.5];
        $customers = ['Zambia National Millers', 'Africa Commodity Exchange', 'Local Market - Chisamba', 'Sunbird Trading', 'City Grocer Chain'];
        while ($cursor <= $now) {
            $m = (int) $cursor->format('n');
            $y = (int) $cursor->format('Y');
            $amount = round(80000 * $shape[$m - 1] * (1 + 0.10 * ($y - 2024)), 2);
            $rows[] = "('" . $customers[$i % count($customers)] . "', " . $amount . ", '" . $cursor->format('Y-m-18') . "')";
            $i++;
            $cursor->modify('+1 month');
        }
        foreach (array_chunk($rows, 300) as $chunk) {
            $pdo->exec("INSERT INTO sales_records (customer_name, amount, sale_date) VALUES " . implode(', ', $chunk));
        }
        error_log("FFMS: Market Analysis demand history seeded (" . count($rows) . " rows).");
    }
} catch (PDOException $e) {
    error_log("Seed (market demand) failed: " . $e->getMessage());
}

// --- Mock data: only seed once, when the farms table is empty ---
try {
    $farmCount = (int) $pdo->query("SELECT COUNT(*) FROM farms WHERE name = 'Green Valley Farm'")->fetchColumn();
    if ($farmCount > 0) {
        return; // mock data already seeded
    }

    // Farms
    $pdo->exec("INSERT INTO farms (name, location, latitude, longitude) VALUES
        ('Green Valley Farm', 'Lusaka', -15.3875, 28.3228),
        ('Kabwe Grain Estates', 'Kabwe', -14.4490, 28.4465),
        ('Mazabuka Dairy Ridge', 'Mazabuka', -15.8560, 27.7595)");

    // Fields
    $pdo->exec("INSERT INTO fields (farm_id, name, size, soil_type) VALUES
        (1, 'Field A', 12.5, 'Loam'),
        (1, 'Field B', 8.0, 'Sandy loam'),
        (2, 'Field C', 10.0, 'Clay'),
        (3, 'Field D', 15.0, 'Black soil')");

    // Crops
    $pdo->exec("INSERT INTO crops (farm_id, name, variety, planting_date, expected_harvest_date) VALUES
        (1, 'Maize', 'SC719 Hybrid', '2025-11-15', '2026-04-20'),
        (1, 'Soybeans', 'Kafue', '2025-12-01', '2026-05-05'),
        (2, 'Wheat', 'Kabwe Star', '2026-05-10', '2026-09-25'),
        (2, 'Sunflower', 'Avanza', '2025-11-20', '2026-03-30'),
        (3, 'Groundnuts', 'Chalimbana', '2025-12-15', '2026-05-10')");

    // Livestock
    $pdo->exec("INSERT INTO livestock (farm_id, type, breed, dob) VALUES
        (3, 'Cattle', 'Brahman', '2022-03-10'),
        (3, 'Cattle', 'Hereford', '2021-06-01'),
        (3, 'Goats', 'Boer', '2023-01-15'),
        (1, 'Poultry', 'Ross 308 (Broilers)', '2026-07-01')");

    // Vaccinations (linked to livestock rows 1-4 above)
    $pdo->exec("INSERT INTO vaccinations (livestock_id, vaccine_name, vaccination_date, next_due_date) VALUES
        (1, 'Anthrax Vaccine', '2026-03-10', '2027-03-10'),
        (2, 'Lumpy Skin Disease Vaccine', '2026-02-15', '2027-02-15'),
        (3, 'PPR Vaccine', '2026-04-01', '2026-10-01'),
        (4, 'Newcastle Disease Vaccine', '2026-07-01', '2027-07-01')");

    // Irrigation
    $pdo->exec("INSERT INTO irrigation_systems (farm_id, type, status) VALUES
        (1, 'Drip', 'Operational'),
        (2, 'Sprinkler', 'Maintenance Required'),
        (3, 'Pivot', 'Operational')");

    // Equipment (types drive sensible service intervals; the tractor is overdue
    // on purpose so the service-reminder badges have something to show).
    $pdo->exec("INSERT INTO equipment (name, maintenance_status, equipment_type, service_interval_days, last_service_date, next_service_date) VALUES
        ('John Deere 5065E Tractor', 'Operational', 'Tractor', 90, '2025-01-10', '2025-04-10'),
        ('Maize Planter 4-Row', 'Operational', 'Planter', 90, NULL, NULL),
        ('Boom Sprayer 2000L', 'Maintenance Required', 'Sprayer', 45, NULL, NULL),
        ('Trailer 10-Tonne', 'Operational', 'Vehicle', 120, NULL, NULL)");

    // Inventory
    $pdo->exec("INSERT INTO inventory (name, quantity, unit) VALUES
        ('Hybrid Maize Seed (SC719)', 120, 'Bags'),
        ('D-Compound Fertilizer', 85, 'Bags'),
        ('Urea Fertilizer', 60, 'Bags'),
        ('Diesel', 2000, 'Litres'),
        ('Acephate Insecticide', 40, 'Litres'),
        ('Veterinary Vaccines', 150, 'Doses')");

    // Labour
    $pdo->exec("INSERT INTO labour_records (farm_id, name, role, attendance_date) VALUES
        (1, 'Mwewa Banda', 'Field Supervisor', '2026-08-20'),
        (1, 'Chanda Phiri', 'General Worker', '2026-08-20'),
        (2, 'Tembo Mulenga', 'Irrigation Operator', '2026-08-21'),
        (3, 'Natasha Zulu', 'Vet Technician', '2026-08-22')");

    // Pests & diseases — unified health_incidents (Phase 3 / B4).
    $pdo->exec("INSERT INTO health_incidents (farm_id, subject_type, issue_name, issue_kind, detected_date, status, treatment_notes) VALUES
        (1, 'crop', 'Fall Armyworm', 'pest', '2026-01-15', 'treated', 'Applied Coragen sprayed 200ml/ha'),
        (2, 'crop', 'Birds (Quelea)', 'pest', '2026-02-10', 'treated', 'Bird scaring + netting deployed'),
        (3, 'livestock', 'Tick Infestation', 'pest', '2026-03-02', 'treated', 'Dipping conducted, acaricide applied')");

    // Harvest records
    $pdo->exec("INSERT INTO harvest_records (crop_id, harvest_date, quantity, quality) VALUES
        (1, '2026-04-18', 8.5, 'Grade A'),
        (1, '2026-04-25', 7.2, 'Grade A'),
        (5, '2026-05-09', 3.1, 'Grade B')");

    // Suppliers
    $pdo->exec("INSERT INTO suppliers (name, contact_info) VALUES
        ('Zamseed Ltd', 'zamseed@co.zm | +260 211 250 000'),
        ('Zambia Fertilizer Co', 'zfc@co.zm | +260 211 220 111'),
        ('AgroFarm Supplies', 'agrofarm@co.zm | +260 977 000 000')");

    // Procurement (cost in ZMW Kwacha)
    $pdo->exec("INSERT INTO procurement_records (supplier_id, item_name, quantity, cost, purchase_date) VALUES
        (1, 'Hybrid Maize Seed', 120, 96000, '2025-10-10'),
        (2, 'D-Compound Fertilizer', 85, 127500, '2025-10-12'),
        (2, 'Urea Fertilizer', 60, 108000, '2025-10-12'),
        (3, 'Acephate Insecticide', 40, 18000, '2026-01-05'),
        (1, 'Diesel (farm tenant)', 2000, 58700, '2026-03-15')");

    // Sales (amount in ZMW Kwacha)
    $pdo->exec("INSERT INTO sales_records (customer_name, amount, sale_date) VALUES
        ('Zambia National Millers', 584000, '2026-05-02'),
        ('Africa Commodity Exchange', 231000, '2026-05-28'),
        ('Local Market - Chisamba', 45200, '2026-06-15')");

    // Finance records (ZMW)
    $pdo->exec("INSERT INTO finance_records (type, amount, description, date) VALUES
        ('expense', 96000, 'Seed purchase - Zamseed', '2025-10-10'),
        ('expense', 235500, 'Fertilizer purchase', '2025-10-12'),
        ('expense', 58700, 'Diesel top-up', '2026-03-15'),
        ('income', 584000, 'Maize sale - ZNM', '2026-05-02'),
        ('income', 231000, 'Soybean sale - ACE', '2026-05-28')");

    // Market data (price per kg in ZMW)
    $pdo->exec("INSERT INTO market_data (crop_name, price, market_date) VALUES
        ('Maize', 3.50, '2026-08-20'),
        ('Soybeans', 7.20, '2026-08-20'),
        ('Wheat', 4.80, '2026-08-20'),
        ('Groundnuts', 12.00, '2026-08-20')");

    // Weather records
    $pdo->exec("INSERT INTO weather_records (farm_id, temperature, humidity, weather_date) VALUES
        (1, 22.5, 45.0, NOW()),
        (2, 21.0, 50.0, NOW()),
        (3, 24.3, 40.0, NOW())");

    // Storage
    $pdo->exec("INSERT INTO storage_records (name, capacity, current_stock, unit) VALUES
        ('Grain Silo 1', 500.0, 320.0, 'kg'),
        ('Grain Silo 2', 500.0, 0.0, 'kg'),
        ('Cold Store', 120.0, 40.0, 'kg')");

    // Notifications
    $pdo->exec("INSERT INTO notifications (message, is_read) VALUES
        ('Inventory: D-Compound Fertilizer is below 100 bags.', FALSE),
        ('Maintenance due: Boom Sprayer 2000L.', FALSE),
        ('Harvest window expected soon for Kabwe Wheat.', FALSE)");

        error_log("FFMS: Mock data seeded successfully.");
} catch (PDOException $e) {
    error_log("Seed (mock data) failed: " . $e->getMessage());
}

// --- Backfill farm_members for all users (idempotent, runs every boot) ---
try {
    $pdo->exec("INSERT INTO farm_members (farm_id, user_id, farm_role)
        SELECT f.id, u.id, u.role FROM farms f CROSS JOIN users u
        ON CONFLICT (farm_id, user_id) DO NOTHING");
} catch (PDOException $e) {
    error_log("Seed (farm_members backfill) failed: " . $e->getMessage());
}
?>