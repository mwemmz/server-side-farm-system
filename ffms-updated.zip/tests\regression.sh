#!/usr/bin/env bash
#
# FFMS regression test (curl-based).
#
# Runs against a LOCAL server + LOCAL PostgreSQL only. Never point BASE at the
# hosted database.
#
# Usage:
#   DB_HOST=localhost DB_PORT=5432 DB_NAME=farm_system DB_USER=postgres DB_PASS=postgres \
#   php -S localhost:8000 -t public &
#   BASE=http://localhost:8000 bash tests/regression.sh
#
# Exits non-zero if any assertion fails.

set -u
BASE="${BASE:-http://localhost:8000}"
USER_NAME="${FFMS_USER:-admin}"
USER_PASS="${FFMS_PASS:-admin123}"
JAR="$(mktemp)"
PHP_LOG="${PHP_LOG:-}"

PASS=0
FAIL=0

ok()   { PASS=$((PASS + 1)); printf '  \033[32mPASS\033[0m %s\n' "$1"; }
bad()  { FAIL=$((FAIL + 1)); printf '  \033[31mFAIL\033[0m %s\n' "$1"; }
check(){ if [ "$2" = "$3" ]; then ok "$1 ($2)"; else bad "$1 (expected '$3', got '$2')"; fi; }
contains(){ if printf '%s' "$1" | grep -qF -- "$2"; then ok "$3"; else bad "$3 (missing: $2)"; fi; }
notcontains(){ if printf '%s' "$1" | grep -qF -- "$2"; then bad "$3 (unexpected: $2)"; else ok "$3"; fi; }

# status: prints HTTP status code for a request (no body)
status() { curl -s -o /dev/null -w '%{http_code}' "$@"; }
# bodycode: prints "STATUS\nBODY"
bodycode() { curl -s -w '\n%{http_code}' "$@"; }
# created_id: the id of the record just created, read from the one-shot
# "Saved successfully" modal (data-created-id) on the redirect target. Must be
# the first fetch after the create POST — the modal is consumed once rendered.
created_id() { curl -s -L -b "$JAR" -c "$JAR" "$@" | grep -o 'data-created-id="[0-9]*"' | head -1 | grep -o '[0-9]*'; }

echo "== FFMS regression @ $BASE =="

# ---------------------------------------------------------------------------
# 1. Login (must fetch the form first to obtain the CSRF token)
# ---------------------------------------------------------------------------
LOGIN_PAGE="$(curl -s -c "$JAR" "$BASE/index.php?module=Security&action=login")"
TOKEN="$(printf '%s' "$LOGIN_PAGE" | grep -o 'name="csrf_token" value="[^"]*"' | head -1 | sed 's/.*value="//; s/"$//')"
if [ -n "$TOKEN" ]; then ok "login page issues a CSRF token"; else bad "login page CSRF token missing"; fi

LOGIN_STATUS="$(status -b "$JAR" -c "$JAR" \
  --data-urlencode "csrf_token=$TOKEN" \
  --data-urlencode "username=$USER_NAME" \
  --data-urlencode "password=$USER_PASS" \
  "$BASE/index.php?module=Security&action=login")"
check "login redirects on success" "$LOGIN_STATUS" "302"

# Refresh the session CSRF token from an authenticated page (it is regenerated on login).
DASH="$(curl -s -b "$JAR" -c "$JAR" "$BASE/index.php?module=Dashboard")"
TOKEN="$(printf '%s' "$DASH" | grep -o 'name="csrf-token" content="[^"]*"' | head -1 | sed 's/.*content="//; s/"$//')"
if [ -n "$TOKEN" ]; then ok "authenticated pages expose the CSRF meta token"; else bad "CSRF meta token missing"; fi

# Grab a couple of real record ids for FK tests.
FARM_ID="$(printf '%s' "$(curl -s -b "$JAR" "$BASE/index.php?module=Livestock&action=manage")" | grep -o "data-value='[0-9]*'" | head -1 | grep -o '[0-9]*')"

# ---------------------------------------------------------------------------
# 2. CSRF: a POST without a token must be refused (403) on several modules
# ---------------------------------------------------------------------------
echo "-- CSRF rejection on POST without token --"
for m in Finance Crop Sales Procurement Livestock; do
  S="$(status -b "$JAR" --data "amount=1" "$BASE/index.php?module=$m&action=add")"
  check "POST $m/add without token -> 403" "$S" "403"
done

# GET-reachable destructive actions must be refused (405)
echo "-- destructive actions must be POST-only --"
for a in "Notifications&action=mark_all_read" "Labour&action=approve&subsection=leave&id=1" "Notifications&action=delete_rule&id=1"; do
  S="$(status -b "$JAR" "$BASE/index.php?module=$a")"
  check "GET $a -> 405" "$S" "405"
done

# ---------------------------------------------------------------------------
# 3. Validation: bad input is rejected, never 500
# ---------------------------------------------------------------------------
echo "-- validation guards --"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "type=banana&amount=100&description=x&date=2020-01-01" "$BASE/index.php?module=Finance&action=add")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Finance type=banana -> 200 (form re-render)" "$S" "200"
contains "$B" "Type must be either Income or Expense" "Finance rejects bad type"

R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "farm_id=$FARM_ID&type=Cattle&breed=Boran&dob=2099-01-01" "$BASE/index.php?module=Livestock&action=add")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "future DOB -> 200 (form re-render)" "$S" "200"
notcontains "$B" "Internal Server Error" "future DOB is not a 500"

R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "livestock_id=1&vaccine_name=X&vaccination_date=2020-01-01&next_due_date=2019-01-01" "$BASE/index.php?module=Livestock&action=vaccinate")"
B="$(printf '%s' "$R" | sed '$d')"
contains "$B" "cannot be before the vaccination date" "next-due before vaccination rejected"

R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "livestock_id=1&vaccine_name=X&vaccination_date=2099-01-01" "$BASE/index.php?module=Livestock&action=vaccinate")"
B="$(printf '%s' "$R" | sed '$d')"
contains "$B" "cannot be in the future" "future vaccination date rejected"

# non-existent FK ids
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "supplier_id=999999&item_name=X&quantity=1&cost=1&purchase_date=2020-01-01" "$BASE/index.php?module=Procurement&action=add")"
B="$(printf '%s' "$R" | sed '$d')"
notcontains "$B" "Internal Server Error" "bad supplier id is not a 500"

# negative / text quantities & amounts
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "customer_name=X&amount=-5&sale_date=2020-01-01" "$BASE/index.php?module=Sales&action=add")"
B="$(printf '%s' "$R" | sed '$d')"
notcontains "$B" "Internal Server Error" "negative amount is not a 500"

# ---------------------------------------------------------------------------
# 4. Pest route redirects into Crop
# ---------------------------------------------------------------------------
echo "-- Pest redirect --"
S="$(status -b "$JAR" "$BASE/index.php?module=Pest")"
case "$S" in 301|302|303|307|308) ok "?module=Pest redirects ($S)";; *) bad "?module=Pest did not redirect (got $S)";; esac

# ---------------------------------------------------------------------------
# 4b. Phase 3 (B1–B7): new endpoints exist and never 500
# ---------------------------------------------------------------------------
echo "-- Phase 3 endpoints --"

# B1: the vaccine catalogue powers the Animal vaccination combo
R="$(bodycode -b "$JAR" "$BASE/index.php?module=Lookup&action=options&category=vaccine_name&parent=Cattle")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Lookup vaccine_name -> 200" "$S" "200"
contains "$B" '"success"' "B1 vaccine catalogue responds with JSON"

# B2: finance category options depend on the record type
S="$(status -b "$JAR" "$BASE/index.php?module=Lookup&action=options&category=finance_category&parent=income")"
check "Lookup finance_category -> 200" "$S" "200"

# B3: a stock-out below zero is refused, never a 500
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "item_id=1&direction=out&quantity=999999&reason=Test" "$BASE/index.php?module=Inventory&action=move")"
B="$(printf '%s' "$R" | sed '$d')"
notcontains "$B" "Internal Server Error" "B3 stock-out below zero never 500s"

# B4: marking a health incident resolved never 500s
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "id=1&status=resolved" "$BASE/index.php?module=Crop&action=incidentStatus")"
case "$S" in 200|302|303) ok "B4 incident status accepted ($S)";; *) bad "B4 incident status (got $S)";; esac

# B5: Assistant "what needs attention today" responds
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "message=what needs attention today" "$BASE/index.php?module=Insights&action=chat")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "B5 assistant attention -> 200" "$S" "200"
contains "$B" '"success"' "B5 assistant returns JSON"

# B6: recording an equipment service never 500s
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "id=1&service_date=$(date +%F)" "$BASE/index.php?module=Equipment&action=recordService")"
case "$S" in 200|302|303) ok "B6 record service accepted ($S)";; *) bad "B6 record service (got $S)";; esac

# B7: a harvest pointing at a missing storage facility is refused, not a 500
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "crop_id=1&harvest_date=$(date +%F)&quantity=5&storage_record_id=999999" "$BASE/index.php?module=Harvest&action=add")"
B="$(printf '%s' "$R" | sed '$d')"
notcontains "$B" "Internal Server Error" "B7 harvest storage never 500s"

# ---------------------------------------------------------------------------
# 4c. Finish-pass Fix 1: inventory.quantity is authoritative.
#     Acceptance: (a) 120 -> out 50 -> 70; (b) out 71 refused, still 70;
#     (c) in 10 -> 80; (d) direction=sideways rejected, no row; (e) two parallel
#     stock-outs cannot overdraw; (f) low-stock badge/insight match the API
#     balance; (g) procurement of an existing item name increases it (no dup).
# ---------------------------------------------------------------------------
echo "-- Fix 1: stock balance honours opening quantity --"

# API helper: login for a JWT, then read the authoritative balance.
JWT="$(curl -s -X POST -H 'Content-Type: application/json' -d "{\"username\":\"$USER_NAME\",\"password\":\"$USER_PASS\"}" "$BASE/api/v1/auth/token" | grep -o '"token":"[^"]*"' | head -1 | sed 's/.*"token":"//; s/"$//')"
if [ -n "$JWT" ]; then ok "Fix1 API JWT issued"; else bad "Fix1 API JWT missing"; fi
apibal() { curl -s -H "Authorization: Bearer $JWT" "$BASE/api/v1/inventory-items/$IT_ID/balance"; }
apibal_num() { printf '%s' "$(apibal)" | grep -o '"balance":[0-9.]*' | sed 's/"balance"://; s/\.0$//'; }
inv_label() { curl -s -b "$JAR" "$BASE/index.php?module=Inventory&action=manage" | grep -o "value='$IT_NAME[^']*'" | head -1 | grep -o '[0-9.]* bag' | tail -1 | sed 's/ bag//'; }

# create a dedicated item (opening quantity 120)
IT_NAME="BalTest$(date +%H%M%S)$RANDOM"
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "name=$IT_NAME" --data "quantity=120&unit=bag" "$BASE/index.php?module=Inventory&action=add")"
check "Fix1(a) create item -> redirect" "$S" "302"
PAGE="$(curl -s -b "$JAR" "$BASE/index.php?module=Inventory&action=manage")"
IT_ID="$(printf '%s' "$PAGE" | grep -o "$IT_NAME[^>]*data-value='[0-9]*'" | head -1 | grep -o "data-value='[0-9]*'" | grep -o '[0-9]*')"
if [ -n "$IT_ID" ]; then ok "Fix1(a) dedicated item created (id=$IT_ID)"; else bad "Fix1(a) could not find created item"; fi
check "Fix1(a) opening 120 is authoritative (API balance = 120)" "$(apibal_num)" "120"
check "Fix1(a) UI label shows 120 as well" "$(inv_label)" "120"

# (a) stock out 50 -> 70
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "item_id=$IT_ID&direction=out&quantity=50&reason=Test" "$BASE/index.php?module=Inventory&action=move")"
check "Fix1(a) out 50 -> redirect" "$S" "302"
check "Fix1(a) balance after out 50 -> 70" "$(apibal_num)" "70"
check "Fix1(a) UI label after out 50 -> 70" "$(inv_label)" "70"

# (b) stock out 71 refused, still 70
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "item_id=$IT_ID&direction=out&quantity=71&reason=Test" "$BASE/index.php?module=Inventory&action=move")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix1(b) out 71 -> form re-render (200)" "$S" "200"
contains "$B" "Not enough stock" "Fix1(b) refusal message shown"
check "Fix1(b) balance still 70" "$(apibal_num)" "70"

# (c) stock in 10 -> 80
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "item_id=$IT_ID&direction=in&quantity=10&reason=Test" "$BASE/index.php?module=Inventory&action=move")"
check "Fix1(c) in 10 -> redirect" "$S" "302"
check "Fix1(c) balance after in 10 -> 80" "$(apibal_num)" "80"

# (d) sideways direction rejected, no row written
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "item_id=$IT_ID&direction=sideways&quantity=5&reason=Test" "$BASE/index.php?module=Inventory&action=move")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix1(d) sideways -> form re-render (200)" "$S" "200"
contains "$B" "Direction must be" "Fix1(d) sideways rejected"
check "Fix1(d) balance unchanged at 80" "$(apibal_num)" "80"
H="$(curl -s -b "$JAR" "$BASE/index.php?module=Inventory&action=history&id=$IT_ID")"
notcontains "$H" "sideways" "Fix1(d) no sideways movement row written"

# (e) two parallel stock-outs of 45 against 80 cannot overdraw -> ends at 35
( curl -s -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "item_id=$IT_ID&direction=out&quantity=45&reason=Parallel" "$BASE/index.php?module=Inventory&action=move" > /tmp/ffms_c1.$$ ) &
P1=$!
( curl -s -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "item_id=$IT_ID&direction=out&quantity=45&reason=Parallel" "$BASE/index.php?module=Inventory&action=move" > /tmp/ffms_c2.$$ ) &
P2=$!
wait "$P1"; wait "$P2"
C1="$(cat /tmp/ffms_c1.$$)"; C2="$(cat /tmp/ffms_c2.$$)"
rm -f /tmp/ffms_c1.$$ /tmp/ffms_c2.$$
case "$C1$C2" in *"Not enough stock"*) ok "Fix1(e) one parallel stock-out refused";; *) bad "Fix1(e) neither parallel stock-out was refused";; esac
check "Fix1(e) final balance 35 (no overdraft)" "$(apibal_num)" "35"

# (f) low-stock reorder rule below current level -> badge, insight and API agree
R="$(curl -s -X POST -H "Authorization: Bearer $JWT" -H 'Content-Type: application/json' -d "{\"item_id\":$IT_ID,\"threshold_qty\":100,\"reorder_qty\":10}" "$BASE/api/v1/reorder-rules")"
contains "$R" '"success":true' "Fix1(f) reorder rule created"
R="$(curl -s -X POST -H "Authorization: Bearer $JWT" "$BASE/api/v1/reorder-check/run")"
contains "$R" '"balance":35' "Fix1(f) reorder check reads authoritative balance"
contains "$R" "$IT_NAME" "Fix1(f) reorder check flags the low-stock item"
PAGE="$(curl -s -b "$JAR" "$BASE/index.php?module=Inventory&action=manage")"
contains "$PAGE" "$IT_NAME" "Fix1(f) inventory page still lists item"
check "Fix1(f) UI badge number equals API balance (35)" "$(inv_label)" "35"
contains "$PAGE" "Low (min 100)" "Fix1(f) low-stock badge threshold shown"

# (g) procurement of the existing item name increases that item, no duplicate
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "supplier_id=1" --data-urlencode "item_name=${IT_NAME,,}" --data "quantity=5&cost=10&purchase_date=2020-01-01" "$BASE/index.php?module=Procurement&action=add")"
check "Fix1(g) procurement redirects" "$S" "302"
check "Fix1(g) balance after purchase of existing item -> 40" "$(apibal_num)" "40"
PAGE="$(curl -s -b "$JAR" "$BASE/index.php?module=Inventory&action=manage")"
# the closed picker lists each matched item exactly once
CNT="$(printf '%s' "$PAGE" | grep -F -- "$IT_NAME" | grep -F -c 'data-value=')"
check "Fix1(g) no duplicate inventory row for the item (count=1)" "$CNT" "1"

# ---------------------------------------------------------------------------
# 4d. Finish-pass Fix 2: "Report a problem" dropdowns render labels, not Array.
#     Acceptance: no >Array<, no numbered placeholder options, and picking an
#     issue saves the plain issue name rather than the "name (kind)" label.
# ---------------------------------------------------------------------------
echo "-- Fix 2: report-a-problem dropdowns --"
B="$(curl -s -b "$JAR" "$BASE/index.php?module=Crop&action=manage")"
notcontains "$B" '>Array<' "Fix2 crop page has no >Array<"
notcontains "$B" "value='0'>Pest" "Fix2 crop Type combo has no numbered options"
B="$(curl -s -b "$JAR" "$BASE/index.php?module=Livestock&action=manage")"
notcontains "$B" '>Array<' "Fix2 livestock page has no >Array<"
notcontains "$B" "value='0'>Disease" "Fix2 livestock Type combo has no numbered options"
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "crop_id=1" --data-urlencode "pest_name=Fall armyworm" --data "issue_kind=pest&severity=Moderate&detected_date=2020-01-01&action_taken=Scouting" "$BASE/index.php?module=Crop&action=addPest")"
check "Fix2 report problem -> redirect" "$S" "302"
B="$(curl -s -b "$JAR" "$BASE/index.php?module=Crop&action=manage")"
contains "$B" '>Fall armyworm<' "Fix2 saved issue name preserved (not the ' (kind)' label)"

# ---------------------------------------------------------------------------
# 4e. Finish-pass Fix 3: the equipment spare-part picker shows live quantity
#     (was selecting id,name,unit but reading ['quantity'] -> always 0).
# ---------------------------------------------------------------------------
echo "-- Fix 3: equipment spare-part picker --"
B="$(curl -s -b "$JAR" "$BASE/index.php?module=Equipment&action=manage")"
SP="$(printf '%s' "$B" | grep -F -- "$IT_NAME" | grep -o '[0-9.]* bag' | tail -1 | sed 's/ bag//')"
check "Fix3 spare picker shows live quantity (40)" "$SP" "40"
notcontains "$B" "Undefined array key" "Fix3 equipment page has no undefined-key warnings"

# ---------------------------------------------------------------------------
# 4f. Finish-pass Fix 4: storage facilities always carry a unit (kg default),
#     can be edited, and "Store in" harvest is refused cleanly on bad ids or
#     capacity (never a 500, never a partial stock change).
# ---------------------------------------------------------------------------
echo "-- Fix 4: storage unit + edit + harvest-to-storage --"
ST1="StorFix$(date +%H%M%S)$RANDOM"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "name=$ST1" --data "capacity=100&current_stock=0" "$BASE/index.php?module=Storage&action=add")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix4 storage add without unit -> 200 (form re-render)" "$S" "200"
contains "$B" "Unit is required." "Fix4 storage add demands a unit"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "name=$ST1" --data "capacity=100&current_stock=0&unit=kg" "$BASE/index.php?module=Storage&action=add")"
S="$(printf '%s' "$R" | tail -1)"
check "Fix4 storage add with unit -> 302" "$S" "302"
SID="$(created_id "$BASE/index.php?module=Storage&action=manage")"
[ -n "$SID" ] && ok "Fix4 located storage facility id ($SID)" || bad "Fix4 storage facility id missing"
STPG="$(curl -s -b "$JAR" "$BASE/index.php?module=Storage&action=manage")"
contains "$STPG" ">${ST1}: 0 / 100 kg" "Fix4 facility created with kg unit"

CR_ID="$(printf '%s' "$(curl -s -b "$JAR" "$BASE/index.php?module=Harvest&action=manage")" | grep -o "data-value='[0-9]*'" | head -1 | grep -o '[0-9]*')"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "crop_id=$CR_ID&harvest_date=2020-01-01&quantity=60&storage_record_id=$SID" "$BASE/index.php?module=Harvest&action=add")"
S="$(printf '%s' "$R" | tail -1)"
check "Fix4 harvest into storage -> 302" "$S" "302"
STPG="$(curl -s -b "$JAR" "$BASE/index.php?module=Storage&action=manage")"
contains "$STPG" ">${ST1}: 60 / 100 kg" "Fix4 harvest 60kg lands in storage"

ST2="StorFixB$(date +%H%M%S)$RANDOM"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "name=$ST2" --data "capacity=100&current_stock=0&unit=tonnes" "$BASE/index.php?module=Storage&action=add")"
check "Fix4 storage B add -> 302" "$(printf '%s' "$R" | tail -1)" "302"
SID2="$(created_id "$BASE/index.php?module=Storage&action=manage")"
[ -n "$SID2" ] && ok "Fix4 located storage facility B id ($SID2)" || bad "Fix4 storage facility B id missing"
STPG="$(curl -s -b "$JAR" "$BASE/index.php?module=Storage&action=manage")"
contains "$STPG" ">${ST2}: 0 / 100 tonnes" "Fix4 facility B tonne unit"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "crop_id=$CR_ID&harvest_date=2020-01-01&quantity=200000&storage_record_id=$SID2" "$BASE/index.php?module=Harvest&action=add")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix4 over-capacity harvest -> 200 (refused)" "$S" "200"
contains "$B" "That would exceed" "Fix4 capacity refusal message"
STPG="$(curl -s -b "$JAR" "$BASE/index.php?module=Storage&action=manage")"
contains "$STPG" ">${ST2}: 0 / 100 tonnes" "Fix4 refused harvest did not change stock"
notcontains "$STPG" "Internal Server Error" "Fix4 over-capacity is not a 500"

R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "crop_id=$CR_ID&harvest_date=2020-01-01&quantity=5&storage_record_id=999999" "$BASE/index.php?module=Harvest&action=add")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix4 unknown storage id -> 200 (refused)" "$S" "200"
contains "$B" "Storage facility not found." "Fix4 unknown storage id refused cleanly"
notcontains "$B" "Internal Server Error" "Fix4 unknown storage id is not a 500"

R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "id=$SID&name=${ST1}Renamed&capacity=200&unit=kg" "$BASE/index.php?module=Storage&action=edit")"
S="$(printf '%s' "$R" | tail -1)"
check "Fix4 storage edit -> 302" "$S" "302"
STPG="$(curl -s -b "$JAR" "$BASE/index.php?module=Storage&action=manage")"
contains "$STPG" ">${ST1}Renamed: 60 / 200 kg" "Fix4 storage edit updates name/capacity"

# ---------------------------------------------------------------------------
# 4h. Item 2 (review pass): storage edit refuses hostile ids, a capacity below
#     the stored stock, and a unit change while stock is inside — never 500.
# ---------------------------------------------------------------------------
echo "-- storage edit guards --"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "id=$SID&name=${ST1}Renamed&capacity=10&unit=kg" "$BASE/index.php?module=Storage&action=edit")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "capacity below stock -> 200 (refused)" "$S" "200"
contains "$B" "Capacity cannot be lower than the current stock of 60 kg" "capacity-below-stock message"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "id=$SID&name=${ST1}Renamed&capacity=200&unit=tonnes" "$BASE/index.php?module=Storage&action=edit")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "unit change with stock stored -> 200 (refused)" "$S" "200"
contains "$B" "Empty the facility before changing its unit" "unit-change-while-stored message"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "id=$SID2&name=$ST2&capacity=100&unit=kg" "$BASE/index.php?module=Storage&action=edit")"
check "unit change with empty facility -> 302" "$(printf '%s' "$R" | tail -1)" "302"
STPG="$(curl -s -b "$JAR" "$BASE/index.php?module=Storage&action=manage")"
contains "$STPG" ">${ST2}: 0 / 100 kg" "empty-facility unit swap applied"
for HID in 0 -1 abc 1e3 99999 9223372036854775807; do
  R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "id=$HID&name=X&capacity=200&unit=kg" "$BASE/index.php?module=Storage&action=edit")"
  S="$(printf '%s' "$R" | tail -1)"
  case "$S" in 200|302) ok "storage edit id=$HID -> $S (no 500)";; *) bad "storage edit id=$HID -> $S";; esac
done
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "id[]=1&name=X&capacity=200&unit=kg" "$BASE/index.php?module=Storage&action=edit")"
S="$(printf '%s' "$R" | tail -1)"
case "$S" in 200|302) ok "storage edit id[]=1 -> $S (no 500)";; *) bad "storage edit id[]=1 -> $S";; esac

# ---------------------------------------------------------------------------
# 4g. Finish-pass Fix 5: a vaccine is only accepted for its species, a batch
#     is one species at a time (atomic), and single-dose vaccines (Marek's)
#     never carry a next due date.
# ---------------------------------------------------------------------------
echo "-- Fix 5: vaccine <-> species checks --"
RAND5="$(date +%H%M%S)$RANDOM"
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "farm_id=$FARM_ID" --data-urlencode "type=Cattle" --data-urlencode "breed=QCattle$RAND5" --data-urlencode "dob=2020-01-01" "$BASE/index.php?module=Livestock&action=add")"
check "Fix5 create cattle -> 302" "$S" "302"
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "farm_id=$FARM_ID" --data-urlencode "type=Goats" --data-urlencode "breed=QGoat$RAND5" --data-urlencode "dob=2020-01-01" "$BASE/index.php?module=Livestock&action=add")"
check "Fix5 create goat -> 302" "$S" "302"
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "farm_id=$FARM_ID" --data-urlencode "type=Poultry" --data-urlencode "breed=QPoultry$RAND5" --data-urlencode "dob=2020-01-01" "$BASE/index.php?module=Livestock&action=add")"
check "Fix5 create poultry -> 302" "$S" "302"
LX="$(curl -s -b "$JAR" "$BASE/index.php?module=Livestock&action=manage")"
CID="$(printf '%s' "$LX" | grep -o "QCattle$RAND5[^>]*data-value='[0-9]*'" | head -1 | grep -o "data-value='[0-9]*'" | grep -o '[0-9]*')"
GID="$(printf '%s' "$LX" | grep -o "QGoat$RAND5[^>]*data-value='[0-9]*'" | head -1 | grep -o "data-value='[0-9]*'" | grep -o '[0-9]*')"
PID="$(printf '%s' "$LX" | grep -o "QPoultry$RAND5[^>]*data-value='[0-9]*'" | head -1 | grep -o "data-value='[0-9]*'" | grep -o '[0-9]*')"
[ -n "$CID" ] && ok "Fix5 cattle id found" || bad "Fix5 cattle id missing"
[ -n "$GID" ] && ok "Fix5 goat id found" || bad "Fix5 goat id missing"
[ -n "$PID" ] && ok "Fix5 poultry id found" || bad "Fix5 poultry id missing"

R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "livestock_id=$CID" --data-urlencode "vaccine_name=Newcastle (NCD) vaccine" --data-urlencode "vaccination_date=2020-01-01" "$BASE/index.php?module=Livestock&action=vaccinate")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix5 cattle + Newcastle -> 200 (refused)" "$S" "200"
contains "$B" "Newcastle (NCD) vaccine is for Poultry" "Fix5 wrong-species message"
contains "$B" "not this Cattle" "Fix5 wrong-species names the animal"
notcontains "$B" "Internal Server Error" "Fix5 species mismatch not a 500"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "livestock_id=$GID" --data-urlencode "vaccine_name=Newcastle (NCD) vaccine" --data-urlencode "vaccination_date=2020-01-01" "$BASE/index.php?module=Livestock&action=vaccinate")"
check "Fix5 goat + Newcastle -> 200 (refused)" "$(printf '%s' "$R" | tail -1)" "200"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "livestock_id=$GID" --data-urlencode "vaccine_name=PPR vaccine" --data-urlencode "vaccination_date=2020-01-01" "$BASE/index.php?module=Livestock&action=vaccinate")"
check "Fix5 goat + PPR -> 302" "$(printf '%s' "$R" | tail -1)" "302"

LX="$(curl -s -b "$JAR" "$BASE/index.php?module=Livestock&action=manage")"
N1="$(printf '%s' "$LX" | grep -F -c '>PPR vaccine<')"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "animal_ids[]=$CID" --data-urlencode "animal_ids[]=$GID" --data-urlencode "vaccine_name=PPR vaccine" --data-urlencode "vaccination_date=2020-01-02" "$BASE/index.php?module=Livestock&action=batchVaccinate")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix5 mixed-species batch -> 200 (refused)" "$S" "200"
contains "$B" "One vaccine batch = one species" "Fix5 mixed batch refused"
notcontains "$B" "Internal Server Error" "Fix5 mixed batch not a 500"
LX="$(curl -s -b "$JAR" "$BASE/index.php?module=Livestock&action=manage")"
N2="$(printf '%s' "$LX" | grep -F -c '>PPR vaccine<')"
check "Fix5 refused batch inserted nothing (PPR count unchanged)" "$N2" "$N1"

R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "animal_ids[]=$CID" --data-urlencode "vaccine_name=PPR vaccine" --data-urlencode "vaccination_date=2020-01-02" "$BASE/index.php?module=Livestock&action=batchVaccinate")"
check "Fix5 cattle-only batch + PPR -> 200 (refused)" "$(printf '%s' "$R" | tail -1)" "200"

R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "animal_ids[]=$PID" --data-urlencode "vaccine_name=Marek's vaccine" --data-urlencode "vaccination_date=2020-01-03" --data-urlencode "next_due_date=2021-06-01" "$BASE/index.php?module=Livestock&action=batchVaccinate")"
check "Fix5 poultry batch + Marek's -> 302" "$(printf '%s' "$R" | tail -1)" "302"
LX="$(curl -s -b "$JAR" "$BASE/index.php?module=Livestock&action=manage")"
contains "$LX" "Marek&#039;s vaccine" "Fix5 Marek's recorded"
contains "$LX" "No next date" "Fix5 single-dose Marek's has no next due date"

# hostile/unknown ids in a batch are refused, never 500, never stored
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "animal_ids[]=$CID" --data-urlencode "animal_ids[]=999999" --data-urlencode "vaccine_name=PPR vaccine" --data-urlencode "vaccination_date=2020-01-04" "$BASE/index.php?module=Livestock&action=batchVaccinate")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix5 batch with a missing animal id -> 200 (refused)" "$S" "200"
notcontains "$B" "Internal Server Error" "Fix5 missing-id batch not a 500"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "animal_ids[]=abc" --data-urlencode "vaccine_name=PPR vaccine" --data-urlencode "vaccination_date=2020-01-05" "$BASE/index.php?module=Livestock&action=batchVaccinate")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix5 batch with a non-integer id -> 200 (refused)" "$S" "200"
contains "$B" "invalid animal id" "Fix5 non-integer id names the problem"
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "animal_ids[$GID]=$CID" --data-urlencode "vaccine_name=PPR vaccine" --data-urlencode "vaccination_date=2020-01-06" "$BASE/index.php?module=Livestock&action=batchVaccinate")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Fix5 batch with a jagged id array -> 200 (not 500)" "$S" "200"
notcontains "$B" "Internal Server Error" "Fix5 jagged id array not a 500"

# ---------------------------------------------------------------------------
# 4i. Finish-pass Fix 6: service reminders — the interval is defaulted from the
#     equipment type server-side, an overdue item is flagged, and recording a
#     service recomputes (and clears) the schedule.
# ---------------------------------------------------------------------------
echo "-- Fix 6: equipment service reminders --"
EQN="EQFix$(date +%H%M%S)$RANDOM"
EQPUR="$(date -d '300 days ago' +%F)"
EQSRV="$(date -d 'yesterday' +%F)"
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data-urlencode "name=$EQN" --data-urlencode "status=Operational" --data-urlencode "equipment_type=Tractor" --data-urlencode "purchase_date=$EQPUR" "$BASE/index.php?module=Equipment&action=add")"
check "Fix6 add tractor (no interval) -> 302" "$S" "302"
LX="$(curl -s -b "$JAR" "$BASE/index.php?module=Equipment&action=manage")"
BLK="$(printf '%s' "$LX" | grep -A45 -F -- ">$EQN<" | head -46)"
contains "$BLK" "Serviced every 90 days" "Fix6 interval defaulted from type"
contains "$BLK" "Service overdue" "Fix6 overdue tractor flagged"
EID="$(printf '%s' "$BLK" | grep -o 'name="id" value="[0-9]*"' | head -1 | grep -o '[0-9]*')"
[ -n "$EID" ] && ok "Fix6 equipment id found" || bad "Fix6 equipment id missing"
S="$(status -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "id=$EID" --data-urlencode "service_date=$EQSRV" "$BASE/index.php?module=Equipment&action=recordService")"
check "Fix6 record service -> 302" "$S" "302"
LX="$(curl -s -b "$JAR" "$BASE/index.php?module=Equipment&action=manage")"
BLK="$(printf '%s' "$LX" | grep -A45 -F -- ">$EQN<" | head -46)"
notcontains "$BLK" "Service overdue" "Fix6 overdue badge cleared after service"
contains "$BLK" "Service OK" "Fix6 schedule recomputed after service"

# ---------------------------------------------------------------------------
# 5. Page sweep: every module x view returns 200 with no PHP warning output
# ---------------------------------------------------------------------------
echo "-- page sweep --"
for url in \
  "module=Dashboard" \
  "module=Crop&action=manage" \
  "module=Livestock&action=manage" \
  "module=Finance&action=manage" \
  "module=Finance&action=loans" \
  "module=Finance&action=budgets" \
  "module=Sales&action=manage" \
  "module=Procurement&action=manage" \
  "module=Inventory&action=manage" \
  "module=Harvest&action=manage" \
  "module=Equipment&action=manage" \
  "module=Storage&action=manage" \
  "module=Irrigation&action=manage" \
  "module=Weather&action=manage" \
  "module=Market&action=manage" \
  "module=Supplier&action=manage" \
  "module=Field&action=manage" \
  "module=Farm&action=manage" \
  "module=Notifications&action=manage" \
  "module=Notifications&action=rules" \
  "module=Labour" \
  "module=Labour&subsection=employees" \
  "module=Labour&subsection=leave" \
  "module=Labour&subsection=shifts" \
  "module=Labour&subsection=payroll" \
  "module=Labour&subsection=training" \
  "module=Labour&subsection=grievances" \
  "module=Labour&subsection=departments" \
  "module=Security&action=change_password" \
  "module=Security&action=users" \
  "module=Security&action=audit" \
  "module=Reports" \
  "module=Analytics" \
  "module=Insights" \
  ; do
  R="$(bodycode -b "$JAR" "$BASE/index.php?$url")"
  S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
  check "GET $url -> 200" "$S" "200"
  notcontains "$B" "Undefined array key" "No 'Undefined array key' on $url"
  notcontains "$B" "Undefined variable" "No 'Undefined variable' on $url"
  notcontains "$B" "Fatal error" "No Fatal error on $url"
  notcontains "$B" "Deprecated:" "No PHP deprecation on $url"
done

# module landings (GET index) must be clean too — Fix 7 touched these templates.
for url in \
  "module=Crop" \
  "module=Inventory" \
  "module=Harvest" \
  "module=Market" \
  "module=Supplier" \
  "module=Procurement" \
  "module=Sales" \
  "module=Notifications" \
  "module=Labour" \
  "module=Analytics" \
  "module=Security" \
  ; do
  B="$(curl -s -b "$JAR" "$BASE/index.php?$url")"
  notcontains "$B" "Undefined array key" "Landing $url: no 'Undefined array key'"
  notcontains "$B" "Undefined variable" "Landing $url: no 'Undefined variable'"
  notcontains "$B" "Fatal error" "Landing $url: no Fatal error"
done

# ---------------------------------------------------------------------------
# 5a2. Control panels: the client script and live JSON must actually be served
#      (on Vercel every unknown path falls through to the PHP front controller,
#       so a missing asset route turns panels.js into an HTML document).
# ---------------------------------------------------------------------------
echo "-- Control panels --"
PJ="$(curl -s -b "$JAR" -o /dev/null -w '%{http_code} %{content_type}' "$BASE/views/js/panels.js")"
check "panels.js served" "$(printf '%s' "$PJ" | cut -d' ' -f1)" "200"
case "$PJ" in
  *javascript*) ok "panels.js has a JavaScript content type" ;;
  *) bad "panels.js has a JavaScript content type (got: $PJ)" ;;
esac
PANEL_JS="$(curl -s -b "$JAR" "$BASE/views/js/panels.js")"
contains "$PANEL_JS" "ff-panel-config" "panels.js is the script, not an HTML error page"
IRR_JSON="$(curl -s -b "$JAR" "$BASE/index.php?module=Irrigation&action=panel_json&id=1")"
contains "$IRR_JSON" '"success":true' "Irrigation panel_json succeeds"
contains "$IRR_JSON" '"reservoir"' "Irrigation panel_json returns reservoir data"
IRR_PAGE="$(curl -s -b "$JAR" "$BASE/index.php?module=Irrigation")"
contains "$IRR_PAGE" 'id="ff-panel-config"' "Irrigation page embeds the panel config"
contains "$IRR_PAGE" 'views/js/panels.js' "Irrigation page loads panels.js"

# ---------------------------------------------------------------------------
# 5b. Animal tags + role landing screens
# ---------------------------------------------------------------------------
echo "-- Animal tags --"
TOKA="$(curl -s -b "$JAR" "$BASE/index.php?module=Dashboard" | grep -oE 'csrf-token" content="[a-f0-9]+' | sed 's/.*content="//')"
FARM_T="$(curl -s -b "$JAR" "$BASE/index.php?module=Livestock&action=manage" | grep -oE "data-value='[0-9]+'" | head -1 | grep -o '[0-9]*')"
add_animal() { curl -s -o /dev/null -w '%{http_code}' -b "$JAR" -c "$JAR" -X POST "$BASE/index.php?module=Livestock&action=add" --data-urlencode "csrf_token=$TOKA" -d "farm_id=$FARM_T&type=Cattle&breed=Boran&dob=2024-01-01" "$@"; }
reg() { curl -s -b "$JAR" "$BASE/index.php?module=Livestock&action=manage"; }
check "animal add without tag -> redirect" "$(add_animal)" "302"
check "animal add with manual tag UAT-4471 -> redirect" "$(add_animal -d tag_no=UAT-4471 -d name=Bella)" "302"
R="$(reg)"
contains "$R" "UAT-4471" "register shows the manual tag"
contains "$R" "COW-" "register shows an auto-generated COW- tag"
check "duplicate tag (case-insensitive) rejected" "$(add_animal -d tag_no=uat-4471)" "200"
check "tag with markup rejected" "$(add_animal --data-urlencode 'tag_no=bad<script>')" "200"
R522="$(add_animal -d 'tag_no[]=x')"; if [ "$R522" = 200 ] || [ "$R522" = 302 ]; then ok "array tag ignored or rejected, not 500 ($R522)"; else bad "array tag gave $R522"; fi
R523="$(add_animal -d 'name[]=x' -d 'sex[]=y')"; if [ "$R523" = 200 ] || [ "$R523" = 302 ]; then ok "array name/sex ignored or rejected, not 500 ($R523)"; else bad "array name/sex gave $R523"; fi
notcontains "$R" "#1 —" "no '#N —' animal labels"
notcontains "$R" ">Array<" "no 'Array' option text on Livestock page"
check "nextTag JSON ok" "$(status -b "$JAR" "$BASE/index.php?module=Livestock&action=nextTag&farm_id=$FARM_T&type=Cattle")" "200"
for bad_id in 0 -1 abc 1e3 99999 9223372036854775807 'id[]=1'; do
  for act in edit profile; do
    c="$(status -b "$JAR" "$BASE/index.php?module=Livestock&action=$act&id=$bad_id")"
    if [ "$c" = "500" ]; then bad "animal $act id=$bad_id returned 500"; else ok "animal $act id=$bad_id -> $c (not 500)"; fi
  done
done

echo "-- Role landing --"
role_login() { # $1 jar $2 user $3 pass -> prints redirect target
  rm -f "$1"
  T="$(curl -s -c "$1" -b "$1" "$BASE/index.php?module=Security&action=login" | grep -oE 'name="csrf_token" value="[a-f0-9]+' | head -1 | sed 's/.*value="//')"
  curl -s -c "$1" -b "$1" -o /dev/null -w '%{redirect_url}' -d "username=$2&password=$3&csrf_token=$T" ${4:+--data-urlencode "return_to=$4"} "$BASE/index.php?module=Security&action=login" | sed "s#^$BASE/##"
}
for r in manager accountant worker; do
  curl -s -o /dev/null -b "$JAR" -c "$JAR" -X POST "$BASE/index.php?module=Security&action=users" --data-urlencode "csrf_token=$TOKA" -d "username=rl_$r&email=rl_$r@example.com&password=abc12345&role=$r"
done
J2="$(mktemp)"
check "admin lands on Dashboard"       "$(role_login "$J2" admin "$USER_PASS")" "index.php?module=Dashboard"
check "manager lands on Dashboard"     "$(role_login "$J2" rl_manager abc12345)" "index.php?module=Dashboard"
check "accountant lands on Finance"    "$(role_login "$J2" rl_accountant abc12345)" "index.php?module=Finance"
check "worker lands on My day"         "$(role_login "$J2" rl_worker abc12345)" "index.php?module=Dashboard&view=today"
check "bare index.php sends worker home" "$(curl -s -o /dev/null -b "$J2" -w '%{redirect_url}' "$BASE/index.php" | sed "s#^$BASE/##")" "index.php?module=Dashboard&view=today"
W="$(curl -s -b "$J2" "$BASE/index.php?module=Dashboard")"
for w in "Total Costs" "Total Sales" "module=Finance" "module=Labour" "action=users"; do notcontains "$W" "$w" "worker dashboard hides: $w"; done
contains "$W" "My day" "worker dashboard is the My day view"
role_login "$J2" rl_manager abc12345 >/dev/null
M="$(curl -s -b "$J2" "$BASE/index.php?module=Dashboard")"
notcontains "$M" "Total Costs" "manager dashboard hides finance totals"
check "worker blocked from Finance" "$(role_login "$J2" rl_worker abc12345 >/dev/null; curl -s -b "$J2" "$BASE/index.php?module=Finance" | grep -c 'Access Denied')" "1"
check "return_to https://evil ignored" "$(role_login "$J2" "$USER_NAME" "$USER_PASS" 'https://evil.example')" "index.php?module=Dashboard"
check "return_to //evil ignored"       "$(role_login "$J2" "$USER_NAME" "$USER_PASS" '//evil.example')" "index.php?module=Dashboard"
check "return_to internal page honoured" "$(role_login "$J2" "$USER_NAME" "$USER_PASS" 'index.php?module=Livestock&action=manage')" "index.php?module=Livestock&action=manage"
rm -f "$J2"

# ---------------------------------------------------------------------------
# 7. Remaining standout endpoints: planner, traceability, translation, and
#    receipt routes must respond with structured, non-500 output.
# ---------------------------------------------------------------------------
echo "-- Standout feature endpoints --"
R="$(bodycode -b "$JAR" "$BASE/index.php?module=Insights&action=planner&area=2&input_cost=100&expected_yield=3&price_forecast=500&plant_month=3")"
check "planner endpoint -> 200" "$(printf '%s' "$R" | tail -1)" "200"
contains "$(printf '%s' "$R" | sed '$d')" '"expected_profit"' "planner returns profit"
R="$(bodycode -b "$JAR" "$BASE/index.php?module=Traceability&action=public&token=invalid-token")"
check "invalid public trace token -> 200" "$(printf '%s' "$R" | tail -1)" "200"
R="$(bodycode -b "$JAR" "$BASE/index.php?module=Insights&action=translate&language=bem&phrase=Save")"
check "translation endpoint -> 200" "$(printf '%s' "$R" | tail -1)" "200"
contains "$(printf '%s' "$R" | sed '$d')" '"translation"' "translation returns a value"

# ---------------------------------------------------------------------------
# 5c. Ops engine: metadata-driven operational records
# ---------------------------------------------------------------------------
echo "-- Ops engine --"
R="$(bodycode -b "$JAR" "$BASE/index.php?module=Ops")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Ops landing -> 200" "$S" "200"
contains "$B" "Soil Conditions" "Ops landing lists soil records"
contains "$B" "Equipment" "Ops landing lists equipment records"
notcontains "$B" "Fatal error" "Ops landing has no fatal error"

R="$(bodycode -b "$JAR" "$BASE/index.php?module=Ops&view=soil_conditions")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Ops records (soil) -> 200" "$S" "200"
contains "$B" "Soil Conditions" "soil records page shows its title"

# The add form lists the real field ids for the FK picker.
R="$(bodycode -b "$JAR" "$BASE/index.php?module=Ops&view=soil_conditions&action=add")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Ops add form -> 200" "$S" "200"
OPS_FIELD="$(printf '%s' "$B" | grep -o "data-value='[0-9]*'" | head -1 | grep -o '[0-9]*')"
if [ -n "$OPS_FIELD" ]; then ok "Ops add form offers a field FK (id=$OPS_FIELD)"; else bad "Ops add form has no field options"; fi

# Required-field validation.
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "notes=x" "$BASE/index.php?module=Ops&view=soil_conditions&action=add")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Ops missing required -> 200 (form re-render)" "$S" "200"
contains "$B" "Field is required" "Ops requires the field"
contains "$B" "Sample date is required" "Ops requires the sample date"

# Numeric validation.
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "field_id=$OPS_FIELD&sample_date=$(date +%F)&ph=banana" "$BASE/index.php?module=Ops&view=soil_conditions&action=add")"
B="$(printf '%s' "$R" | sed '$d')"
contains "$B" "pH must be a number" "Ops rejects a non-numeric pH"

# Future date validation.
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "field_id=$OPS_FIELD&sample_date=2099-01-01" "$BASE/index.php?module=Ops&view=soil_conditions&action=add")"
B="$(printf '%s' "$R" | sed '$d')"
contains "$B" "cannot be in the future" "Ops rejects a future sample date"

# Non-existent FK validation.
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "field_id=999999&sample_date=$(date +%F)" "$BASE/index.php?module=Ops&view=soil_conditions&action=add")"
B="$(printf '%s' "$R" | sed '$d')"
contains "$B" "no longer exists" "Ops rejects a missing FK target"

# Cross-field date ordering.
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "field_id=$OPS_FIELD&start_date=2024-05-01&end_date=2024-04-01" "$BASE/index.php?module=Ops&view=field_history&action=add")"
B="$(printf '%s' "$R" | sed '$d')"
contains "$B" "cannot be before" "Ops rejects an end date before the start date"

# Invoice payment cannot exceed the total.
R="$(bodycode -b "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "invoice_date=$(date +%F)&total_amount=100&amount_paid=150" "$BASE/index.php?module=Ops&view=invoices&action=add")"
B="$(printf '%s' "$R" | sed '$d')"
contains "$B" "Amount paid cannot exceed the total amount" "Ops rejects overpayment"

# A valid record is created and then visible in the list.
S="$(status -b "$JAR" -c "$JAR" --data-urlencode "csrf_token=$TOKEN" --data "field_id=$OPS_FIELD&sample_date=$(date +%F)&ph=6.5&organic_matter_pct=3.2" "$BASE/index.php?module=Ops&view=soil_conditions&action=add")"
check "Ops valid create -> redirect" "$S" "302"
contains "$(curl -s -b "$JAR" "$BASE/index.php?module=Ops&view=soil_conditions")" "6.5" "created soil record is listed"

# Destructive actions stay POST-only, unknown views 404.
check "Ops delete via GET -> 405" "$(status -b "$JAR" "$BASE/index.php?module=Ops&view=soil_conditions&action=delete&id=1")" "405"
check "Ops unknown view -> 404" "$(status -b "$JAR" "$BASE/index.php?module=Ops&view=does_not_exist")" "404"

echo "-- Ops RBAC --"
OW="$(mktemp)"
curl -s -o /dev/null -b "$JAR" -c "$JAR" -X POST "$BASE/index.php?module=Security&action=users" --data-urlencode "csrf_token=$TOKA" -d "username=ops_worker&email=ops_worker@example.com&password=abc12345&role=worker"
role_login "$OW" ops_worker abc12345 >/dev/null
check "worker can open Ops landing" "$(status -b "$OW" "$BASE/index.php?module=Ops")" "200"
check "worker denied crop-write Ops view" "$(status -b "$OW" "$BASE/index.php?module=Ops&view=planting_records")" "403"
check "worker denied Analytics" "$(status -b "$OW" "$BASE/index.php?module=Analytics")" "403"
check "worker denied Reports" "$(status -b "$OW" "$BASE/index.php?module=Reports")" "403"
rm -f "$OW"

# ---------------------------------------------------------------------------
# 5d. Analytics landing, report exports and new KPI integration
# ---------------------------------------------------------------------------
echo "-- Analytics & reports --"
R="$(bodycode -b "$JAR" "$BASE/index.php?module=Analytics")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Analytics landing -> 200" "$S" "200"
contains "$B" "Farm Analytics" "analytics landing renders"
contains "$B" "Yield per hectare" "analytics landing shows yields"
notcontains "$B" "Fatal error" "analytics landing has no fatal error"

R="$(bodycode -b "$JAR" "$BASE/index.php?module=Analytics&from=2024-01-01&to=2024-12-31")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Analytics range filter -> 200" "$S" "200"
contains "$B" "2024-01-01" "analytics honours the from date"

R="$(bodycode -b "$JAR" "$BASE/index.php?module=Reports&action=export&dataset=soil")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Report export (soil) -> 200" "$S" "200"
contains "$B" "sample_date" "soil export contains its columns"
check "Report export unknown dataset -> 400" "$(status -b "$JAR" "$BASE/index.php?module=Reports&action=export&dataset=nope")" "400"

R="$(bodycode -b "$JAR" "$BASE/index.php?module=Reports&action=printable&dataset=invoices")"
S="$(printf '%s' "$R" | tail -1)"; B="$(printf '%s' "$R" | sed '$d')"
check "Printable report (invoices) -> 200" "$S" "200"
contains "$B" "FFMS Invoices Report" "printable report renders its title"

# The dashboard links analytics figures for finance roles only.
contains "$(curl -s -b "$JAR" "$BASE/index.php?module=Dashboard")" "Profit (YTD)" "dashboard shows the profit KPI to finance roles"

# ---------------------------------------------------------------------------
# 5e. Wave 1-4 endpoints (API smoke)
# ---------------------------------------------------------------------------
echo "-- Wave endpoints --"
JWT="$(curl -s -X POST -H 'Content-Type: application/json' -d "{\"username\":\"$USER_NAME\",\"password\":\"$USER_PASS\"}" "$BASE/api/v1/auth/token" | grep -o '"token":"[^"]*"' | head -1 | sed 's/.*"token":"//; s/"$//')"
if [ -n "$JWT" ]; then ok "Wave JWT issued"; else bad "Wave JWT missing"; fi
H="Authorization: Bearer $JWT"
for ep in "analytics/profit/by-field" "analytics/profit/by-animal" "extranet/connections" "intranet/conversations" "credit-passport/me"; do
  S="$(curl -s -o /dev/null -w '%{http_code}' -H "$H" "$BASE/api/v1/$ep")"
  check "GET $ep -> 200" "$S" "200"
done
# intranet conversation create + message
CID="$(curl -s -H "$H" -H 'Content-Type: application/json' -d '{"title":"regression","members":[]}' "$BASE/api/v1/intranet/conversations" | grep -o '"conversation_id":[0-9]*' | grep -o '[0-9]*')"
if [ -n "$CID" ]; then ok "Wave intranet conversation created"; else bad "Wave intranet conversation create"; fi
if [ -n "$CID" ]; then
  S="$(curl -s -o /dev/null -w '%{http_code}' -H "$H" -H 'Content-Type: application/json' -d '{"body":"hi"}' "$BASE/api/v1/intranet/conversations/$CID/messages")"
  check "Wave intranet message -> 200" "$S" "200"
  S="$(curl -s -o /dev/null -w '%{http_code}' -H "$H" "$BASE/api/v1/intranet/conversations/$CID/messages")"
  check "Wave intranet messages list -> 200" "$S" "200"
fi
# credit passport share + public page
SHARE="$(curl -s -H "$H" -H 'Content-Type: application/json' -d '{"scope":["score"],"expires_days":7}' "$BASE/api/v1/credit-passport/share" | grep -o '"token":"[^"]*"' | head -1 | sed 's/.*"token":"//; s/"$//')"
if [ -n "$SHARE" ]; then ok "Wave credit passport share created"; else bad "Wave credit passport share"; fi
if [ -n "$SHARE" ]; then
  S="$(curl -s -o /dev/null -w '%{http_code}' "$BASE/index.php?module=CreditPassport&token=$SHARE")"
  check "Wave public credit passport page -> 200" "$S" "200"
fi
# traceability batch
BC="REG$(date +%s)"
S="$(curl -s -o /dev/null -w '%{http_code}' -H "$H" -H 'Content-Type: application/json' -d "{\"batch_code\":\"$BC\",\"quantity\":5,\"unit\":\"kg\"}" "$BASE/api/v1/traceability/batches")"
check "Wave traceability batch create -> 200" "$S" "200"
BID="$(curl -s -H "$H" -H 'Content-Type: application/json' -d "{\"batch_code\":\"$BC\",\"quantity\":5,\"unit\":\"kg\"}" "$BASE/api/v1/traceability/batches" | grep -o '"id":[0-9]*' | head -1 | grep -o '[0-9]*')"
if [ -n "$BID" ]; then
  S="$(curl -s -o /dev/null -w '%{http_code}' -H "$H" -H 'Content-Type: application/json' -d '{"event_type":"storage","location":"shed"}' "$BASE/api/v1/traceability/batches/$BID/events")"
  check "Wave traceability event -> 200" "$S" "200"
  S="$(curl -s -o /dev/null -w '%{http_code}' -H "$H" "$BASE/api/v1/traceability/batches/$BID")"
  check "Wave traceability batch get -> 200" "$S" "200"
  # Public provenance lookup must work with the token the create response hands out.
  PB="$(curl -s "$BASE/index.php?module=Traceability&action=public&token=$BC")"
  contains "$PB" '"success":true' "traceability public JSON via token"
  contains "$PB" "$BC" "traceability public JSON carries the batch code"
fi
# planting what-if
S="$(curl -s -o /dev/null -w '%{http_code}' -H "$H" -H 'Content-Type: application/json' -d '{"crop_id":1,"planting_month":3,"area_ha":2,"input_cost_estimate":100}' "$BASE/api/v1/planner/planting-what-if")"
check "Wave planting-what-if -> 200" "$S" "200"
# marketplace
S="$(curl -s -o /dev/null -w '%{http_code}' "$BASE/index.php?module=Marketplace")"
check "Wave marketplace page -> 200" "$S" "200"
# communications
S="$(curl -s -o /dev/null -w '%{http_code}' -b "$JAR" "$BASE/index.php?module=Communications")"
check "Wave communications page -> 200" "$S" "200"
# connections
S="$(curl -s -o /dev/null -w '%{http_code}' -b "$JAR" "$BASE/index.php?module=Connections")"
check "Wave connections page -> 200" "$S" "200"
# credit passport manage
S="$(curl -s -o /dev/null -w '%{http_code}' -b "$JAR" "$BASE/index.php?module=CreditPassport")"
check "Wave credit passport manage -> 200" "$S" "200"

# ---------------------------------------------------------------------------
# 5f. Labour leave self-service (worker slice)
# ---------------------------------------------------------------------------
echo "-- Labour leave access --"
WJAR="$(mktemp)"
WLOGIN_PAGE="$(curl -s -c "$WJAR" "$BASE/index.php?module=Security&action=login")"
WTOKEN="$(printf '%s' "$WLOGIN_PAGE" | grep -o 'name="csrf_token" value="[^"]*"' | head -1 | sed 's/.*value="//; s/"$//')"
WLOGIN="$(status -b "$WJAR" -c "$WJAR" \
  --data-urlencode "csrf_token=$WTOKEN" \
  --data-urlencode "username=rl_worker" \
  --data-urlencode "password=abc12345" \
  "$BASE/index.php?module=Security&action=login")"
check "worker login redirects" "$WLOGIN" "302"

WLEAVE="$(curl -s -b "$WJAR" -c "$WJAR" "$BASE/index.php?module=Labour&subsection=leave")"
WTOKEN="$(printf '%s' "$WLEAVE" | grep -o 'name="csrf_token" value="[^"]*"' | head -1 | sed 's/.*value="//; s/"$//')"
check "worker can open leave page" "$(status -b "$WJAR" "$BASE/index.php?module=Labour&subsection=leave")" "200"
contains "$WLEAVE" "My Leave" "worker sees the self-service nav"
contains "$WLEAVE" "Ruth Banda" "worker sees their own employee record"
notcontains "$WLEAVE" "Oscar Phiri" "worker cannot see another employee"
notcontains "$WLEAVE" "HR view" "worker does not get the HR panel"

WPAYROLL="$(curl -s -b "$WJAR" "$BASE/index.php?module=Labour&subsection=payroll")"
contains "$WPAYROLL" "Access Denied" "worker blocked from payroll"
WEMP="$(curl -s -b "$WJAR" "$BASE/index.php?module=Labour&subsection=employees")"
contains "$WEMP" "Access Denied" "worker blocked from employee records"

WAPPROVE="$(curl -s -b "$WJAR" --data-urlencode "csrf_token=$WTOKEN" "$BASE/index.php?module=Labour&subsection=leave&action=approve&id=1")"
contains "$WAPPROVE" "Access Denied" "worker cannot approve leave"

ADMINLEAVE="$(curl -s -b "$JAR" "$BASE/index.php?module=Labour&subsection=leave")"
contains "$ADMINLEAVE" "HR view" "admin still gets the HR leave panel"

# ---------------------------------------------------------------------------
# 6. Optional: no new PHP warnings (when PHP_LOG points at the server log)
# ---------------------------------------------------------------------------
if [ -n "$PHP_LOG" ] && [ -f "$PHP_LOG" ]; then
  echo "-- PHP log scan --"
  if grep -q "PHP Warning\|PHP Fatal\|Undefined array key\|Undefined variable\|Deprecated:" "$PHP_LOG"; then
    bad "PHP warnings/notices/fatals found in $PHP_LOG"
  else
    ok "no PHP warnings/notices/fatals in $PHP_LOG"
  fi
fi

rm -f "$JAR"
echo
echo "== $PASS passed, $FAIL failed =="
[ "$FAIL" -eq 0 ]
